<?php
/**
* Plugin Name: Shahr  Login/Signup 
* Plugin URI: https://shahrwp.com/shahr-login
* Author: Mehdi Torkaman
* Version: 2.1
* Text Domain: shahr-login
* Domain Path: /languages
* Author URI: https://shahrwp.com
* Description: user  can login/sign up  .
* Tags: login, signup, register, woocommerce, popup

*/


//Exit if accessed directly
if( !defined( 'ABSPATH' ) ){
	return;
}
define( 'SHAHR_LOG', true);
define( 'SHAHR_LOG_PLUGIN_FILE', __FILE__ );
if ( ! class_exists( 'Shahr_Log_Core' ) ) {
	require_once 'includes/class-shahr-log-core.php';
}

if( !function_exists( 'shahr_log' ) ){
	function shahr_log(){
		do_action('shahr_log_before_plugin_activation');
		return Shahr_Log_Core::get_instance();
		
	}
}
add_action( 'plugins_loaded', 'shahr_log', 8 );
