jQuery(document).ready(function ($) {
	var formsTrigger = {
		'shahr-log-login-tgr': 'login',
		'shahr-log-reg-tgr': 'register',
		'shahr-log-lostpw-tgr': 'lostpw',
		'shahr-log-resetpw-tgr': 'resetpw',
		'shahr-log-otp-tgr': 'otp'
	}
	class Container {
		constructor($container) {
			this.$container = $container;
			this.$tabs = $container.find('ul.shahr-log-tabs').length ? $container.find('ul.shahr-log-tabs') : null;
			this.display = $container.hasClass('shahr-log-form-inline') ? 'inline' : 'popup';

			if (this.$container.attr('data-active')) {
				this.toggleForm(this.$container.attr('data-active'));
			}

			this.eventHandlers();
		}
		eventHandlers() {
			this.formTriggerEvent();
			this.$container.on('submit', '.shahr-log-action-form', this.submitForm.bind(this));
		}
		formTriggerEvent() {
			var container = this;
			$.each(formsTrigger, function (triggerClass, formType) {
				$(container.$container).on('click', '.' + triggerClass, function (e) {
					e.preventDefault();
					e.stopImmediatePropagation();
					container.toggleForm(formType);
				})
			});
		}
		toggleForm(formType) {

			this.$container.attr('data-active', formType);
			var $section = this.$container.find('.shahr-log-section[data-section="' + formType + '"]'),
				activeClass = 'shahr-log-active';

			//Setting section
			if ($section.length) {
				this.$container.find('.shahr-log-section').removeClass(activeClass);
				$section.addClass(activeClass);
				$section.find('.shahr-log-notice').html('').hide();
				$section.find('.shahr-log-action-form').show();
			}
			//Setting Tab
			if (this.$tabs) {
				this.$tabs.find('li').removeClass(activeClass);
				if (this.$tabs.find('li[data-tab="' + formType + '"]').length) {
					this.$tabs.find('li[data-tab="' + formType + '"]').addClass(activeClass);
				}
			}

			$(document.body).trigger('shahr_log_form_toggled', [formType, this]);

		}
		submitForm(e) {
			e.preventDefault();
			var $form = $(e.currentTarget),
				$button = $form.find('button[type="submit"]'),
				$section = $form.parents('.shahr-log-section'),
				buttonTxt = $button.text(),
				$notice = $section.find('.shahr-log-notice'),
				formType = $section.attr('data-section'),
				container = this;
			$button.html(shahr_log_localize.html.spinner).addClass('shahr-log-processing');

			var form_data = $form.serialize() + '&action=shahr_log_form_action' + '&display=' + container.display;

			$.ajax({
				url: shahr_log_localize.adminurl,
				type: 'POST',
				data: form_data,
				success: function (response) {

					$button.removeClass('shahr-log-processing').html(buttonTxt);
					//Unexpected response
					if (response.error === undefined) {
						console.log(response);
						location.reload();
						return;
					}
					if (response.notice) {

						$notice.html(response.notice).show();

						//scrollbar position
						if (container.display === 'inline') {
							$('html, body').animate({ scrollTop: $notice.offset().top - 100 }, 500);
						}
					}
					if (response.error === 0 && response.type != 'otp') {

						if (response.redirect) {
							//Redirect
							setTimeout(function () {
								window.location = response.redirect;
							}, shahr_log_localize.redirectDelay);
						}

						else {
							$form.hide();
						}
						$form.trigger('reset');

						if (formType === 'resetpw') {
							$form.add('.shahr-log-resetpw-hnotice').remove();
						}
					}
					
					if (response.status == 1000 || response.status == 2000) {
						$('.shahr-log-otp-username_cont').addClass("shahr-log-code-otp-hidden").removeClass("shahr-log-password-otp-show");
						$('.shahr-log-otp-password_cont').removeClass("shahr-log-password-otp-hidden").attr("required", "required");
						$("#shahr_log_otp_change_username").removeClass('shahr-log-password-otp-hidden').addClass('shahr-log-password-otp-show');

						if (response.status == 1000) {
							$("#shahr_log_form_id").val("otp_set_password");
						}
						if (response.status == 2000) {
							$("#shahr_log_form_id").val("otp_login_password");
							$("#otp_userid_id").val(String(response.userid));
							$("#shahr_log_otp_send_id").removeClass("shahr-log-password-otp-hidden").addClass('shahr-log-password-otp-show');
						}
						if (response.status < 1000) {
							$("#otp_userid_id").val('false');
						}
						if (response.status == 112) {
							setTimeout(function () {
								window.location = response.redirect;
							}, shahr_log_localize.redirectDelay);
						}

					}
					if (response.status == 1100) {
						setTimeout(function () {
							window.location = response.redirect;
						}, shahr_log_localize.redirectDelay);
					}
					$(document.body).trigger('shahr_log_form_submitted', [response, $form, container]);
				}
			})
		}

	}
	class Popup {
		constructor($popup) {
			this.$popup = $popup;
			this.eventHandlers();
			this.initScrollbar();
		}

		eventHandlers() {
			this.$popup.on('click', '.shahr-log-close, .shahr-log-modal', this.closeOnClick.bind(this));
			$(document.body).on('shahr_log_form_submitted', this.onFormSubmitSuccess.bind(this));
			this.$popup.on('click', '.shahr-log-action-btn', this.setScrollBarOnSubmit.bind(this));
			$(window).on('hashchange load', this.openViaHash.bind(this));
			this.triggerPopupOnClick(); //Open popup using link
		}

		triggerPopupOnClick() {

			$.each(formsTrigger, function (triggerClass, formType) {

				$(document.body).on('click', '.' + triggerClass, function (e) {

					if ($(this).parents('.shahr-log-form-container').length) return true; //Let container class handle

					e.preventDefault();
					e.stopImmediatePropagation();

					popup.toggle('show');

					if ($(this).attr('data-redirect')) {
						popup.$popup.find('input[name="shahr_log_redirect"]').val($(this).attr('data-redirect'));
					}

					popup.$popup.find('.' + triggerClass).trigger('click');

					return false;

				})

			})

		}

		initScrollbar() {
			this.$scrollbar = Scrollbar.init(this.$popup.find('.shahr-log-srcont').get(0));
		}

		toggle(type) {
			var $els = this.$popup.add('body'),
				activeClass = 'shahr-log-popup-active';

			if (type === 'show') {
				$els.addClass(activeClass);
			}
			else if (type === 'hide') {
				$els.removeClass(activeClass);
			}
			else {
				$els.toggleClass(activeClass);
			}

			$(document.body).trigger('shahr_log_popup_toggled', [type]);
		}

		closeOnClick(e) {
			var elClassList = e.target.classList;
			if (elClassList.contains('shahr-log-close') || elClassList.contains('shahr-log-modal')) {
				this.toggle('hide');
			}
		}

		setScrollbarPosition(position) {
			this.$scrollbar.scrollTop = position || 0;
		}

		onFormSubmitSuccess(e, response, $form, container) {
			this.setScrollbarPosition();
		}

		setScrollBarOnSubmit(e) {
			var invalid_els = $(e.currentTarget).closest('form').find('input:invalid');
			if (invalid_els.length === 0) return;
			this.setScrollbarPosition(invalid_els.filter(":first").closest('.shahr-log-aff-group').position().top);
		}

		openViaHash() {
			var hash = $(location).attr('hash');
			if (hash === '#login') {
				this.toggle('show');
				this.$popup.find('.shahr-log-login-tgr').trigger('click');
			}
			else if (hash === '#register') {
				this.toggle('show');
				this.$popup.find('.shahr-log-reg-tgr').trigger('click');
			}
		}

	}

	class Form {

		constructor($form) {
			this.$form = $form;
		}

		eventHandlers() {

		}

	}

	var popup = null;

	//Popup
	if ($('.shahr-log-container').length) {
		popup = new Popup($('.shahr-log-container'));
	}
	//Auto open popup
	if (shahr_log_localize.autoOpenPopup === 'yes' && localStorage.getItem("shahr_log_popup_opened") !== "yes") {

		if (shahr_log_localize.autoOpenPopupOnce === "yes") {
			localStorage.setItem("shahr_log_popup_opened", "yes");
		}

		setTimeout(function () {
			popup.toggle('show');
		}, shahr_log_localize.aoDelay);
	}
	$('.shahr-log-form-container').each(function (key, el) {
		new Container($(el));
	})

	//Trigger popup if reset field is active
	if ($('form.shahr-log-form-resetpw').length) {
		if ($('.shahr-log-form-inline').length) {
			$([document.documentElement, document.body]).animate({
				scrollTop: $(".shahr-log-form-inline").offset().top
			}, 500);
		}
		else {
			if (popup) {
				popup.toggle('show');
			}
		}
	}
	if ($('body.woocommerce-checkout').length && $('.shahr-log-form-inline').length && $('a.showlogin').length) {
		var $inlineForm = $('.shahr-log-form-inline');
		$inlineForm.hide();
		$(document.body).on('click', 'a.showlogin', function () {
			$inlineForm.slideToggle();
			$inlineForm.find('.shahr-log-login-tgr').trigger('click');
		});
	}
	$("#shahr_log_otp_send_id").click(function () {
		let phone_number = $('input[name="shahr-log-otp-username"]').val();
		login_otp_text = $("#shahr_log_otp_send_id").text();
		if (shahr_log_localize.OTP_enable == 'yes') {
			$("#shahr_log_otp_send_id").html(shahr_log_localize.html.spinner).addClass('shahr-log-processing');
			$.post({
				url: shahr_log_localize.adminurl,
				type: 'POST',
				data: {
					'action': 'shahr_log_otp_form_action',
					'phone_number': phone_number,
					'nonce': shahr_log_localize.otp_nonce,
				},
			}).done(function (response, status) {
				
				$("#shahr_log_otp_send_id").removeClass('shahr-log-processing').html(login_otp_text);
				if (response.status == 3000) {
					debugger;
					$('.shahr-log-otp-password_cont').addClass("shahr-log-password-otp-hidden").removeClass(".shahr-log-password-otp-show");
					$("#shahr_log_otp_change_username").removeClass('shahr-log-password-otp-hidden').addClass('shahr-log-password-otp-show');
					$("#otp_input_id").removeClass("shahr-log-code-otp-hidden").addClass("shahr-log-password-otp-show");
					$("#shahr_log_otp_send_id").addClass('shahr-log-password-otp-hidden').removeClass('shahr-log-password-otp-show');
					$("#shahr_log_otp_change_action_id").removeClass('shahr-log-password-otp-hidden').addClass("shahr-log-password-otp-show");
					$("#shahr_log_form_id").val("otp_authentication");
					$(".shahr-log-otp-username_cont").addClass("shahr-log-password-otp-hidden");
					$(".shahr-log-notice").css({ 'display': 'none' });
					$("#shahr_log_form_id").val("otp_authentication");
					$("#shahr_log_otp_send_again_id").removeClass('shahr-log-password-otp-hidden').addClass('shahr-log-password-otp-show');
				}

			}).fail(function (response, status) {
				$("#shahr_log_otp_send_id").removeClass('shahr-log-processing').html(login_otp_text);
				$("#shahr_log_otp_send_id").addClass('shahr-log-password-otp-hidden').removeClass('shahr-log-password-otp-show');

			});

		}
	});
	$("#shahr_log_otp_send_again_id").click(function(){
		let phone_number = $('input[name="shahr-log-otp-username"]').val();
		let login_otp_text_send_again = $("#shahr_log_otp_send_again_id").text();
		$("#shahr_log_otp_send_again_id").html(shahr_log_localize.html.spinner).addClass('shahr-log-processing');
		$.post({
			url: shahr_log_localize.adminurl,
			type: 'POST',
			data: {
				'action': 'shahr_log_otp_form_action',
				'phone_number': phone_number,
				'nonce': shahr_log_localize.otp_nonce,
			},
			
		}).done(function (response, status) {
			
			$("#shahr_log_otp_send_again_id").removeClass('shahr-log-processing').html(login_otp_text_send_again);
			if (response.status == 3000) {
				function startTimer(duration, display) {
					var timer = duration,  seconds;
					var otp_time=setInterval(function () {		
						seconds = parseInt(timer % 60, 10);
						seconds = seconds < 10 ? "0" + seconds : seconds;
						display.text(seconds);
						if (--timer < 0) {
							clearInterval(otp_time);
							$("#shahr_log_otp_send_again_id").attr("disabled",false)
							$("#shahr_log_otp_send_again_id").html(login_otp_text_send_again);
						}
					}, 1000);
				}
				$(function ($) {
					var fiveMinutes = 60 ,
						display = $('#shahr_log_otp_send_again_id');
					startTimer(fiveMinutes, display);
				});
				$("#shahr_log_otp_send_again_id").attr("disabled",true)
			}

		}).fail(function (response, status) {
			$("#shahr_log_otp_send_again_id").attr("disabled",false)
			$("#shahr_log_otp_send_again_id").removeClass('shahr-log-processing').html(login_otp_text_send_again);
		});
	})
	$("#shahr_log_otp_change_action_id").click(function () {
		$("#otp_input_id").removeClass("shahr-log-password-otp-show").addClass("shahr-log-code-otp-hidden").val("");
		$("#shahr_log_otp_change_action_id").addClass('shahr-log-password-otp-hidden').removeClass("shahr-log-password-otp-show");
		$('.shahr-log-otp-password_cont').addClass("shahr-log-password-otp-show").removeClass("shahr-log-password-otp-hidden");
		$('input[name="shahr-log-otp-password"]').val("");
		$("#shahr_log_form_id").val("otp_login_password");
		$("#shahr_log_otp_send_id").addClass('shahr-log-password-otp-show').removeClass('shahr-log-password-otp-hidden');
		$(".shahr-log-notice").css({ 'display': 'none' });

	});
	$("#shahr_log_otp_change_username").click( function () {
		$("#shahr_log_otp_change_username").addClass('shahr-log-password-otp-hidden').removeClass('shahr-log-password-otp-show');
		$(".shahr-log-otp-username_cont").removeClass('shahr-log-password-otp-hidden').addClass('shahr-log-password-otp-show');
		$(".shahr-log-notice").css({ 'display': 'none' });
		$('.shahr-log-otp-password_cont').addClass("shahr-log-password-otp-hidden").removeClass(".shahr-log-password-otp-show").val("");
		$("#shahr_log_otp_send_id").addClass('shahr-log-password-otp-hidden').removeClass('shahr-log-password-otp-show');
		$("#shahr_log_otp_change_action_id").addClass('shahr-log-password-otp-hidden').removeClass('shahr-log-password-otp-show');
		$(".shahr-log-otp-code_cont").addClass('shahr-log-password-otp-hidden').removeClass('shahr-log-password-otp-show');
		$("#shahr_log_form_id").val("otp");
		$("#shahr_log_otp_send_again_id").addClass('shahr-log-password-otp-hidden').removeClass('shahr-log-password-otp-show');

	});
//	$("#pinwrapper").pincodeInput({ "inputs": shahr_log_localize.OTP_count, 'hidedigits': false });
})
