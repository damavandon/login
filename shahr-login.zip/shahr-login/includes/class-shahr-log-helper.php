<?php

class Shahr_Log_Helper extends Parent_Shahr_Log_Helper{

	protected static $_instance = null;

	public static function get_instance( $slug, $path ){
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self( $slug, $path );
		}
		return self::$_instance;
	}

	public function get_general_option( $subkey = '' ){
		return $this->get_option( 'shahr-log-gl-options', $subkey );
	}

	public function get_style_option( $subkey = '' ){
		return $this->get_option( 'shahr-log-sy-options', $subkey );
	}


	public function get_advanced_option( $subkey = '' ){
		return $this->get_option( 'shahr-log-av-options', $subkey );
	}
	
	public function get_otp_option( $subkey = '' ){
		return $this->get_option( 'shahr-log-otp-options', $subkey );
	}

}

function shahr_log_helper(){
	return Shahr_Log_Helper::get_instance( 'shahr-login', SHAHR_LOG_PATH );
}
shahr_log_helper();

?>