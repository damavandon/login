<?php

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
class Shahr_Log_Frontend
{
	protected static $_instance = null;
	public $glSettings;
	public $otp_option;
	public static function get_instance()
	{
		if (is_null(self::$_instance)) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public function __construct()
	{
		$this->glSettings = shahr_log_helper()->get_general_option();
		$this->otp_option=  shahr_log_helper()->get_otp_option();
		$this->hooks();
	}
	public function hooks()
	{
		add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
		add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
		add_action('wp_footer', array($this, 'popup_markup'));
		add_shortcode('shahr_log_action', array($this, 'markup_shortcode'));
		add_filter('shahr_log_shahr-login_get_template', array($this, 'force_plugin_templates_over_outdated'), 10, 4);
	}
	//Enqueue stylesheets
	public function enqueue_styles()
	{
		wp_enqueue_style('shahr-log-style', SHAHR_LOG_URL . '/assets/css/shahr-log-style.css', array(), SHAHR_LOG_VERSION_FR);
		wp_enqueue_style('shahr-log-fonts', SHAHR_LOG_URL . '/assets/css/shahr-log-fonts.css', array(), SHAHR_LOG_VERSION_FR);
		wp_enqueue_style('jquery-pinlogin', SHAHR_LOG_URL . '/assets/css/jquery-pinlogin.css', array(), SHAHR_LOG_VERSION_FR);
		ob_start();
		shahr_log_helper()->get_template('/global/inline-style.php');
		wp_add_inline_style('shahr-log-style',  ob_get_clean() . stripslashes(shahr_log_helper()->get_advanced_option('m-custom-css')));
	}

	//Enqueue javascript
	public function enqueue_scripts()
	{
		//Enqueue Form field framework scripts
		shahr_log()->aff->enqueue_scripts();
		//Scrollbar
		if (apply_filters('shahr_log_custom_scrollbar', true)) {
			wp_enqueue_script('smooth-scrollbar', SHAHR_LOG_URL . '/library/smooth-scrollbar/smooth-scrollbar.js', array('jquery'), SHAHR_LOG_VERSION_FR, true); // Main JS
		}
		wp_enqueue_script('shahr-log-js', SHAHR_LOG_URL . '/assets/js/shahr-log-js.js', array('jquery'), SHAHR_LOG_VERSION_FR, true); // Main JS
		wp_enqueue_script('jquery-pinlogin', SHAHR_LOG_URL . '/assets/js/jquery-pinlogin.js', array('jquery'), SHAHR_LOG_VERSION_FR, true); // Main JS

		wp_localize_script('shahr-log-js', 'shahr_log_localize', array(
			'adminurl'  		=> admin_url() . 'admin-ajax.php',
			'redirectDelay' 	=> apply_filters('shahr_log_redirect_delay', 300),
			'html' 				=> array(
				'spinner' => '<i class="fas fa-circle-notch spinner fa-spin" aria-hidden="true"></i>',
			),
			'autoOpenPopup' 	=> $this->is_auto_open_page() ? 'yes' : 'no',
			'autoOpenPopupOnce' => $this->glSettings['ao-once'],
			'aoDelay' 			=> $this->glSettings['ao-delay'],
			'OTP_enable' 		=> $this->otp_option['OTP_enable'],
			'OTP_count' 		=> $this->otp_option['OTP_number_of_authentication'],
			'is_rtl'            => is_rtl(),
			'otp_nonce'         =>wp_create_nonce('otp_nonce'),
		));
	}
	public function is_auto_open_page()
	{
		if (!trim($this->glSettings['ao-pages'])) {
			$pages = array();
		} else {
			$pages = array_map('trim', explode(',', $this->glSettings['ao-pages']));
		}

		$isPage = $this->glSettings['ao-enable'] === "yes" && (empty($pages) || is_page($pages));

		return apply_filters('shahr_log_is_auto_open_page', $isPage, $pages);
	}


	//Add popup to footer
	public function popup_markup()
	{
		if (is_user_logged_in()) return;
		shahr_log_helper()->get_template('shahr-log-popup.php');
	}

	//Shortcode
	public function markup_shortcode($user_atts)
	{

		$atts = shortcode_atts(array(
			'action' 			=> 'login', // For version < 1.3
			'type'				=> 'login',
			'text' 				=> 'ورود/ثبت نام',
			'change_to' 		=> 'logout',
			'change_to_text' 	=> 'خروج',
			'display' 			=> 'link',
			'redirect_to' 		=> ''
		), $user_atts, 'shahr_log_action');
		   $class = 'shahr-log-action-sc ';

		if ($atts['display'] === 'button') {
			$class .= 'button btn ';
		}

		if (is_user_logged_in()) {

			$change_to_text = esc_html($atts['change_to_text']);

			if ($atts['change_to'] === 'myaccount') {
				$change_to_link = wc_get_page_permalink('myaccount');
				$change_to_text =  !empty($change_to_text) ? $change_to_text : __('My account', 'shahr-login');
			} else if ($atts['change_to'] === 'logout') {
				$logout_link 	= !empty($this->glSettings['m-red-logout']) ? $this->glSettings['m-red-logout'] : $_SERVER['REQUEST_URI'];
				$change_to_link = wp_logout_url($logout_link);
				$change_to_text =  !empty($change_to_text) ? $change_to_text : __('Logout', 'shahr-login');
			} else {
				$change_to_link = esc_html($atts['change_to']);
				$change_to_text =  !empty($change_to_text) ? $change_to_text : __('Logout', 'shahr-login');
			}

			$html =  '<a href="' . $change_to_link . '" class="' . $class . '">' . $change_to_text . '</a>';
		} else {
			$action_type = isset($user_atts['action']) ? $user_atts['action'] : $atts['type'];
			switch ($action_type) {
				case 'login':
					$class .= 'shahr-log-login-tgr';
					$text  	= __('Login', 'shahr-login');
					break;

				case 'register':
					$class .= 'shahr-log-reg-tgr';
					$text  	= __('Signup', 'shahr-login');
					break;

				case 'lost-password':
					$class .= 'shahr-log-lostpw-tgr';
					$text 	= __('Lost Password', 'shahr-login');
					break;
				case 'otp':
					$class .= 'shahr-log-otp-tgr';
					$text 	= __('OTP', 'shahr-login');
					break;

				default:
					$class .= 'shahr-log-login-tgr';
					$text 	= __('Login', 'shahr-login');
					break;
			}

			if ($atts['text']) {
				$text = esc_html($atts['text']);
			}

			if ($atts['redirect_to'] === 'same') {
				$redirect = $_SERVER['REQUEST_URI'];
			} elseif ($atts['redirect_to']) {
				$redirect = $atts['redirect_to'];
			} else {
				$redirect = false;
			}

			$redirect = $redirect ? 'data-redirect="' . esc_url($redirect) . '"' : '';

			$html = sprintf('<a class="%1$s" %2$s>%3$s</a>', $class, $redirect, $text);
		}
		return $html;
	}

	public function force_plugin_templates_over_outdated($template, $template_name, $args, $template_path)
	{
		$templates_data = shahr_log_helper()->get_theme_templates_data();

		if (empty($templates_data) || $templates_data['has_outdated'] !== 'yes') return $template;

		$templates = $templates_data['templates'];

		foreach ($templates as $template_data) {
			if ($template_data['is_outdated'] === "yes" && version_compare($template_data['theme_version'], '2.0', '<')  && basename($template_name) === $template_data['basename'] && @md5_file($template) === @md5_file($template_data['file'])) {
				return SHAHR_LOG_PATH . '/templates/' . $template_name;
			}
		}
		return $template;
	}
}
function shahr_log_frontend()
{
	return Shahr_Log_Frontend::get_instance();
}
shahr_log_frontend();
