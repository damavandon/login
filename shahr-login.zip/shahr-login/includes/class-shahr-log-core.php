<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


class Shahr_Log_Core{

	private static $_instance = null;

	public $aff;

	public static function get_instance(){

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	public function __construct(){
		$this->define_constants();
		$this->includes();
		$this->hooks();
	}


	public function define_constants(){
		define( "SHAHR_LOG_PATH", plugin_dir_path( SHAHR_LOG_PLUGIN_FILE ) ); // Plugin path
		define( "SHAHR_LOG_URL", untrailingslashit( plugins_url( '/', SHAHR_LOG_PLUGIN_FILE ) ) ); // plugin url
		define( "SHAHR_LOG_PLUGIN_BASENAME", plugin_basename( SHAHR_LOG_PLUGIN_FILE ) );
		define( "SHAHR_LOG_VERSION_FR", "2" ); //Plugin version
	}

	public function includes(){

		//wpshahr framework
		require_once SHAHR_LOG_PATH.'/includes/shahr-log-framework/shahr-log-framework.php';
		require_once SHAHR_LOG_PATH.'/includes/class-shahr-log-helper.php';

		//Field framework
		require_once SHAHR_LOG_PATH.'/shahr-log-form-fields-fw/shahr-log-aff.php';

		$this->aff = shahr_log_aff_fire( 'shahr-login', 'shahr-log-fields' ); // start framework
		
		require_once SHAHR_LOG_PATH.'includes/shahr-log-functions.php';

		if($this->is_request('frontend')){

			require_once SHAHR_LOG_PATH.'includes/class-shahr-log-frontend.php';
			require_once SHAHR_LOG_PATH.'includes/class-shahr-log-form-handler.php';

		}

		if ($this->is_request('admin')) {
			require_once SHAHR_LOG_PATH.'admin/class-shahr-log-admin-settings.php';
			require_once SHAHR_LOG_PATH.'admin/class-shahr-log-aff-field.php';
			require_once SHAHR_LOG_PATH.'admin/class-shahr-log-user-profile.php';
			require_once SHAHR_LOG_PATH.'admin/class-shahr-log-menu-settings.php';
		}
	}


	public function hooks(){
	//	add_action( 'init', array( $this, 'on_install' ), 0 );
		add_action( 'admin_notices', array( $this, 'show_outdated_template_notice' ) );
		add_action( 'admin_head', array( $this, 'inline_styling' ) );
	}



	/**
	 * What type of request is this?
	 *
	 * @param  string $type admin, ajax, cron or frontend.
	 * @return bool
	 */
	private function is_request( $type ) {
		switch ( $type ) {
			case 'admin':
				return is_admin();
			case 'ajax':
				return defined( 'DOING_AJAX' );
			case 'cron':
				return defined( 'DOING_CRON' );
			case 'frontend':
				return ( ! is_admin() || defined( 'DOING_AJAX' ) ) && ! defined( 'DOING_CRON' );
		}
	}
	public function otp_login_update_notice(){
		?>
		<div class="notice is-dismissible notice-warning" style="padding: 10px; font-weight: 600; font-size: 16px; line-height: 2">This version of login/signup popup is not compatible with the current version of OTP Login plugin. <br>Please update the OTP login plugin.</div>
		<?php
	}
	public function admin_notice_on_install(){
		?>
		<!-- <div class="notice notice-success is-dismissible shahr-log-admin-notice">
			<p>Start by adding Login/Registration links to your <a href="<?php echo admin_url( 'nav-menus.php?shahr_log_nav=true' ); ?>">menu</a>.</p>
			<p>Check <a href="<?php //echo admin_url( 'admin.php?page=shahr-login-settings' ); ?>">Settings & Shortcodes</a></p>
		</div> -->
		<?php
	}
	public function show_outdated_template_notice(){

		$themeTemplatesData = shahr_log_helper()->get_theme_templates_data();
		if( empty( $themeTemplatesData ) || $themeTemplatesData['has_outdated'] !== 'yes' ) return;
		?>
		<div class="notice notice-success is-dismissible shahr-log-admin-notice">
		<p><?php printf( 'You have <a href="%1$s">outdated templates</a> in your theme which are no longer supported. Please fetch a new copy from the plugin folder.<br>Afterwards go to <a href="%1$s">Settings</a> & click on check again. Until then plugin will use the default templates', admin_url( 'admin.php?page=shahr-log' ) ); ?></p>
		</div>
		<?php
	}
	public function inline_styling(){
		?>
		<style type="text/css">
			.notice.shahr-log-admin-notice p {
			    font-size: 16px;
			}
			.notice.shahr-log-admin-notice{
			    border: 2px solid #007cba;
			}
		</style>
		<?php
	}
}
?>