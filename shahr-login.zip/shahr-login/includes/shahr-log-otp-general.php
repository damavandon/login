<?php
function generate_opt_code($count){
    $min = (string)"1";
    $max = (string)"9";
    if (strlen(trim($count))) {
        $count = (int)$count - 1;
        while ($count) {
            $max = $max . strval(9);$min = $min . strval(0);--$count;
        }
        return rand((int)$min,(int)$max);
    }
    return  rand(10000, 9999);
}
function otp_check_message(){
   if(strlen(Shahr_Log_Form_Handler::$otpSettings['OTP_Message'])<10){
   return Shahr_Log_Form_Handler::$otpSettings['OTP_Message']=__('your OTP authentication is {authentication}');
   }
   return Shahr_Log_Form_Handler::$otpSettings['OTP_Message'];
}