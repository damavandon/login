<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

//Menu items filter
if( !function_exists( 'shahr_log_nav_menu_items' ) ):
	function shahr_log_nav_menu_items( $items ) {

		if( empty( $items ) || !is_array( $items ) ) return;


		$actions_classes = array(
			'shahr-log-login-tgr',
			'shahr-log-reg-tgr',
			'shahr-log-lostpw-tgr',
			'shahr-log-logout-menu',
			'shahr-log-myaccount-menu',
			'shahr-log-username-menu',
			'shahr-log-firstname-menu'
		);

		$user = wp_get_current_user();

		foreach ( $items as $key => $item ) {

			$classes = $item->classes;

			if( !empty( $action_class = array_values( array_intersect( $actions_classes, $classes ) ) ) ){

				$action_class = $action_class[0];

				if( is_user_logged_in() ){

					if( $action_class === "shahr-log-myaccount-menu" ){
						//do nothing
						continue;
					}
					elseif( $action_class === "shahr-log-logout-menu" ){
						if( $item->url ) continue;
						$glSettings = shahr_log_helper()->get_general_option();
						$logout_redirect = !empty( $glSettings['m-red-logout'] ) ? $glSettings['m-red-logout'] : $_SERVER['REQUEST_URI'];
						$item->url = wp_logout_url($logout_redirect);
					}
					elseif( $action_class === "shahr-log-firstname-menu"){
						
						$name = !$user->user_firstname ? $user->user_login : $user->user_firstname;
						$item->title = get_avatar($user->ID).str_replace( 'firstname' , $name , $item->title );
						if( class_exists('woocommerce') ){
							$item->url 	 = wc_get_page_permalink( 'myaccount' );
						}
					}
					elseif( $action_class === "shahr-log-username-menu"){
						$item->title = get_avatar($user->ID).str_replace( 'username' , $user->user_login , $item->title );
						if( class_exists('woocommerce') ){
							$item->url 	 = wc_get_page_permalink( 'myaccount' );
						}
					}
					else{
						unset($items[$key]);
					}

				}
				else{
					if( $action_class === "shahr-log-logout-menu" || $action_class === "shahr-log-myaccount-menu" ||  $action_class === "shahr-log-username-menu"  || $action_class === "shahr-log-firstname-menu"){
						unset($items[$key]);
					}

				}

			}
		}

		return $items;
	}
	add_filter('wp_nav_menu_objects','shahr_log_nav_menu_items',11);
endif;


//Add notice
function shahr_log_add_notice( $notice_type = 'error', $message, $notice_class = null ){

	$classes = $notice_type === 'error' ? 'shahr-log-notice-error' : 'shahr-log-notice-success';
	
	$classes .= ' '.$notice_class;

	$html = '<div class="'.$classes.'">'.$message.'</div>';
	
	return apply_filters('shahr_log_notice_html',$html,$message,$classes);
}

//Print notices
function shahr_log_notice_container( $form, $args ){

	global $limit_login_attempts_obj;

	$notices = '';

	if($form === 'login' && !shahr_log_is_limit_login_ok() ){
		$notices .= '<div class="shahr-log-lla-notice"><div class="shahr-log-notice-error">'.$limit_login_attempts_obj->error_msg().'</div></div>';
	}

	$notices .= '<div class="shahr-log-notice"></div>';

	echo apply_filters( 'shahr_log_notice_container', $notices, $form );

}

add_action( 'shahr_log_before_form', 'shahr_log_notice_container',10, 2 );

//Is limit login ok
function shahr_log_is_limit_login_ok(){
	global $limit_login_attempts_obj;
	//return if limit login plugin doesn't exist
	if( !$limit_login_attempts_obj ) return true;

	return $limit_login_attempts_obj->is_limit_login_ok();

}


//Inline Form Shortcode
if( !function_exists( 'shahr_log_inline_form' ) ){
	function shahr_log_inline_form_shortcode($user_atts){

		$atts = shortcode_atts( array(
			'active'	=> 'login',
		), $user_atts, 'shahr_log_inline_form');

		if( is_user_logged_in() ) return;

		$args = array(
			'form_active' 	=> $atts['active'],
			'return' 		=> true
		); 
		
		return shahr_log_get_form( $args );

	}
	add_shortcode( 'shahr_log_inline_form', 'shahr_log_inline_form_shortcode' );
}


function shahr_log_get_form( $args = array() ){
	$form_active='login';
	$glSettings 	= shahr_log_helper()->get_general_option();
	$glSettings 	+= shahr_log_helper()->get_otp_option();
	if($glSettings['OTP_enable']=='yes')$form_active='otp';
	$defaults = array(
		'display' 		=> 'inline',
		'form_active' 	=> $form_active,
		'return' 		=> false,
		'forms' => array(
			'otp' 		=> array(
				'enable' 	=> $glSettings['OTP_enable']
			),
			'login' 		=> array(
				'enable' 	=> 'yes'
			),
			'register' 		=> array(
				'enable' => $glSettings['m-en-reg']
			),
			'lostpw' 		=> array(
				'enable' 	=> 'yes'
			),
			'resetpw' 		=> array(
				'enable' 	=> 'yes'
			),
		)
	);

	$args = wp_parse_args( $args, $defaults );

	if( $glSettings['m-reset-pw'] === "yes" && ( isset( $_GET['reset_password'] ) || isset( $_GET['show-reset-form'] ) ) ){

		$args['form_active'] = 'resetpw';

		$user = new WP_Error();

		if ( isset( $_COOKIE[ 'wp-resetpass-' . COOKIEHASH ] ) && 0 < strpos( $_COOKIE[ 'wp-resetpass-' . COOKIEHASH ], ':' ) ) {  // @codingStandardsIgnoreLine

			list( $rp_id, $rp_key ) = explode( ':', wp_unslash( $_COOKIE[ 'wp-resetpass-' . COOKIEHASH ] ), 2 ); // @codingStandardsIgnoreLine
			$userdata               = get_userdata( absint( $rp_id ) );
			$rp_login               = $userdata ? $userdata->user_login : '';
			$user                   = check_password_reset_key( $rp_key, $rp_login );

			$args['forms']['resetpw'] = array_merge( array(
				'user' 		=> $user,
				'rp_login'	=> $rp_login,
				'rp_key' 	=> $rp_key 
			), $args['forms']['resetpw'] );

		}

	}
	else{
		unset( $args['forms'][ 'resetpw' ] );
	}


	return shahr_log_helper()->get_template( 'shahr-log-form.php', array( 'args' => $args ), '', $args['return'] );
}

//Override woocommerce form login template
function shahr_log_override_myaccount_login_form( $located, $template_name, $args, $template_path, $default_path ){

	if( $template_name === 'myaccount/form-login.php' && shahr_log_helper()->get_general_option( 'm-en-myaccount' ) === "yes" ){
		$located = shahr_log_helper()->locate_template( 'shahr-log-wc-form-login.php', SHAHR_LOG_PATH.'/templates/' );
	}
	return $located;
}
add_filter( 'wc_get_template', 'shahr_log_override_myaccount_login_form', 99999, 5 );



//Override woocommerce form login template
function shahr_log_override_wc_login_form( $located, $template_name, $args, $template_path, $default_path ){

	$glSettings 	  	= shahr_log_helper()->get_general_option();
	$enable_myaccount 	= $glSettings['m-en-myaccount'];
	$enable_checkout 	= $glSettings['m-en-chkout'];

	if( ( $template_name === 'myaccount/form-login.php' && $enable_myaccount === "yes" ) || ( $template_name === 'global/form-login.php' && $enable_checkout === "yes" ) ){
		$located = shahr_log_helper()->locate_template( 'shahr-log-wc-form-login.php', SHAHR_LOG_PATH.'/templates/' );
	}
	return $located;
}
add_filter( 'wc_get_template', 'shahr_log_override_wc_login_form', 99999, 5 );


function shahr_log_get_myaccount_fields(){

	$fields = (array) shahr_log()->aff->fields->get_fields_data();

	foreach ( $fields as $field_id => $field_data )  {

		//Skip if predefined field
		if( !isset( $field_data['settings']['display_myacc'] ) || $field_data['settings']['display_myacc'] !== 'yes' ){
			unset( $fields[ $field_id ] );
		}
	}

	$fields = apply_filters( 'shahr_log_myaccount_fields', $fields );

	return $fields;

}


//Add fields to woocommerce account edit page
function shahr_log_myaccount_details(){

	$fields = shahr_log_get_myaccount_fields();

	if( empty($fields) ) return;

	$args = array(
		'icon' 			=> false,
		'validation' 	=> 'yes',
	);

	$user_id = get_current_user_id();

	$first_half = false;

	foreach ( $fields as $field_id => $field_data ) {

		$args[ 'cont_class'] = array( 'shahr-log-aff-myacc-field', 'woocommerce-form-row', 'form-row', 'shahr-log-aff-'.$field_data['input_type'] );

		if( isset( $field_data['settings']['cols'] ) ){
			if( $field_data['settings']['cols'] === 'one' ){
				$args['cont_class'][] = 'form-row-wide';
				$first_half = false;
			}
			else{
				if( $first_half ){
					$args['cont_class'][] = 'form-row-last';
					$first_half = false;
				}
				else{
					$args['cont_class'][] = 'form-row-first';
					$first_half = true;
				}
			}
		}
		
		$field_value = get_user_meta( $user_id, $field_id, true );

		$args['value'] = $field_value;
		$args['return'] = true;

		echo shahr_log()->aff->fields->get_field_html( $field_id, $args );

	}

}
add_action('woocommerce_edit_account_form','shahr_log_myaccount_details', 10);


function shahr_log_save_myaccount_details( $user_id  ){

	$fields = shahr_log_get_myaccount_fields();

	if( empty( $fields ) ) return;

	foreach ( $fields as $field_id => $field_data ) {
		
		$settings = $field_data[ 'settings' ];
		if( empty( $settings ) ) continue;

		//If active & required & empty user input , throw error
		if( $settings['active'] === "yes" && $settings['required'] === "yes" &&  ( !isset( $_POST[ $field_id ] ) || trim( $_POST[$field_id ] ) == '' )  ){

			$label = isset( $settings['label'] ) && trim( $settings['label'] ) ? trim( $settings['label'] ) : trim( $settings['placeholder'] );

			switch ( $field_data['input_type'] ) {
				case 'checkbox_single':
					$error= sprintf( esc_attr__( 'Please check %s', 'shahr-login' ), $label );
					break;
				
				default:
					$error = sprintf( esc_attr__( '%s cannot be empty', 'shahr-login' ), $label );
					break;
			}
			
			wc_add_notice( $error, 'error' );
		}
		else{
			if( is_array( $_POST[ $field_id ] ) ){
				$field_value = $_POST [ $field_id ];
			}
			else{
				$field_value = sanitize_text_field( $_POST[ $field_id ] );
			}
			update_user_meta( $user_id, $field_id, $field_value );
		}
	}

}
add_action('woocommerce_save_account_details','shahr_log_save_myaccount_details', 10);


function shahr_log_register_generate_password(){
	if( !class_exists( 'woocommerce' ) ) return;
	$aff = shahr_log()->aff->fields;
	$fields = $aff->get_fields_data();
	if( isset( $fields['shahr_log_reg_pass'] ) && $fields['shahr_log_reg_pass']['settings']['active'] === "no" ){
		add_filter( 'pre_option_woocommerce_registration_generate_password', function(){ return 'yes'; } );
	}
}
add_action( 'init', 'shahr_log_register_generate_password' );


//Auto fil woocommerce fields
function shahr_log_autofill_wc_fields( $customer_id, $customer_data ){
	if( !class_exists( 'woocommerce' ) ) return;
	$customer = new Wc_Customer( $customer_id );
	if( !$customer ) return;

	$aff = shahr_log()->aff->fields;
	$fields = $aff->get_fields_data();
	$firstname = isset( $fields['shahr_log_reg_fname'] ) ? $fields['shahr_log_reg_fname'] : false;
	$lastname = isset( $fields['shahr_log_reg_lname'] ) ? $fields['shahr_log_reg_lname'] : false;

	if( $firstname ){
		if( isset( $firstname['settings']['shahr_log_merge_wc_field'] ) && $firstname['settings']['shahr_log_merge_wc_field'] === "yes" ){
			update_user_meta( $customer_id, 'billing_first_name', $customer->get_first_name() );
			update_user_meta( $customer_id, 'shipping_first_name', $customer->get_first_name() );
		}
	}

	if( $lastname ){
		if( isset( $lastname['settings']['shahr_log_merge_wc_field'] ) && $lastname['settings']['shahr_log_merge_wc_field'] === "yes" ){
			update_user_meta( $customer_id, 'billing_last_name', $customer->get_last_name() );
			update_user_meta( $customer_id, 'shipping_last_name', $customer->get_last_name() );
		}
	}
}
add_action( 'shahr_log_created_customer', 'shahr_log_autofill_wc_fields', 10, 2 );


function shahr_log_redirect_endpoints(){
	
	if( shahr_log_helper()->get_general_option( 'm-ep-success' ) !== "yes" ) return;

	add_filter( 'shahr_log_login_redirect', function( $redirect ){
		return add_query_arg( 'login', 'success', $redirect );
	} );
	 
	add_filter( 'shahr_log_register_redirect', function( $redirect ){
		return add_query_arg( 'login', 'success', $redirect );
	} );
}
add_action( 'init', 'shahr_log_redirect_endpoints' );


?>