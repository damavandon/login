<?php
	
if( !isset( $id ) || !isset( $value ) ){
	echo 'Input Id/ Value not set';
	return;
}

?>
<div class="shahr-log-as-upload-container">
	<a class="button-primary shahr-log-upload-icon">Select</a>
	<input type="hidden" name="<?php echo $id; ?>" class="shahr-log-upload-url" value="<?php echo $value; ?>">
	<a class="button shahr-log-remove-media">Remove</a>
	<span class="shahr-log-upload-title"></span>
</div>