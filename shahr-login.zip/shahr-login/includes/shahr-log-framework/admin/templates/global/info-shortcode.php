<?php if( empty( $shortcodes ) ) return; ?>

<div class="shahr-log-sc-shortcodes">
	<h3>Shortcodes</h3>
	<?php foreach ( $shortcodes as $key => $data ): ?>
		<div class="shahr-log-sc-container">
			<div>
				<span class="shahr-log-sc-name"><?php echo $data['shortcode'] ?></span> - <span class="shahr-log-sc-desc"><?php echo $data['desc'] ?></span>
			</div>
			<span class="shahr-log-sc-example">Eg: <?php echo $data['example'] ?></span>

			<?php if( isset( $data['atts'] ) ): ?>
				<table class="shahr-log-sc-table">

					<tr>
						<th>Attribute</th>
						<th>Expected</th>
						<th>Default</th>
						<th>Description</th>
					</tr>

					<?php foreach ( $data['atts'] as $attData){
						echo '<tr>';
						foreach ( $attData as $keyTD => $valueTD ) {
							echo '<td>'.$valueTD.'</td>';	
						}
						echo '</tr>';
					} ?>
				</table>
			<?php endif; ?>
		</div>

	<?php endforeach; ?>
</div>