<div class="shahr-log-settings-container">

	<ul class="shahr-log-sc-tabs">
		<?php foreach( $tabs as $tab_id => $tab_data ): ?>
			<li data-tab="<?php echo $tab_id; ?>" <?php if( $tab_data['pro'] === 'yes' ) echo 'class="shahr-log-as-is-pro"'; ?>><?php echo $tab_data['title']; ?></li>
		<?php endforeach; ?>
	</ul>

	<form class="shahr-log-as-form">

		<?php foreach( $tabs as $tab_id => $tab_data ): ?>
			<div class="shahr-log-sc-tab-content <?php if( $tab_data['pro'] === 'yes' ) echo 'shahr-log-as-is-pro'; ?>" data-tab="<?php echo $tab_id; ?>">
				<?php do_action( 'shahr_log_tab_page_start', $tab_id, $tab_data ); ?>
				<?php $adminObj->create_settings_html( $tab_id ); ?>
				<?php do_action( 'shahr_log_tab_page_end', $tab_id, $tab_data ); ?>
			</div>
		<?php endforeach; ?>

		<div class="shahr-log-sc-bottom-btns">
			<?php if( $hasPRO ): ?>
				<a class="shahr-log-as-pro-toggle">Show/Hide Pro options</a>
			<?php endif; ?>
			<button type="submit" class="shahr-log-as-form-save">Save</button>
			<a class="shahr-log-as-form-reset" href="<?php echo esc_url( add_query_arg( 'reset', true ) ) ?>">Reset</a>
		</div>

	</form>

</div>