<?php
if( !function_exists( 'shahr_log_framework_includes' ) ){
	if( !defined( 'SHAHR_LOG_DIR_FR' ) ){
		define( 'SHAHR_LOG_DIR_FR' , __DIR__ );
	}
	function shahr_log_framework_includes(){
		require_once __DIR__.'/class-shahr-log-helper.php';
		require_once __DIR__.'/class-shahr-log-exception.php';
	}
	shahr_log_framework_includes();
}