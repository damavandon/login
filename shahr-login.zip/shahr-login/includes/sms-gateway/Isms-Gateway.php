<?php
interface Isms_Gateway{
    public static  function send_otp();
    public static  function authentication();
    public function error_code();
    public static function  int();
}