﻿<?php
/*
 * Class Name : GFHANNANSMS_Pro_{strtoupper( php file name) }	
 */

class shahr_log_raygansms implements Isms_Gateway
{
	private static $username = null;
	private static $password = null;
	public static $phone_number = null;
	private static $otp = null;
	private static $input_otp = null;
	public  static $user = null;
	public  static $otp_number = null;
	public  static $message = null;
	public  static $number_of = null;
	public  static $url_send_message = 'https://RayganSMS.com/SendMessageWithUrl.ashx';
	public function __construct()
	{
		self::int();
	}
	public static function send_otp()
	{
		if (is_null(self::$username) || is_null(self::$password)) return false;
		self::$otp = generate_opt_code(self::$number_of);
		if (self::$message == 'default') {
			self::$message = (string)" سلام  کد احراز هویت شما می باشد " . self::$otp;
		} else {
			self::$message = str_replace('{authentication}',self::$otp, self::$message);
		}
		$postdata = http_build_query(array(
			'UserName' => self::$username,
			'Password' => self::$password,
			'PhoneNumber' => self::$otp_number,
			'MessageBody' => self::$message,
			'RecNumber' => self::$phone_number,
			'Smsclass' => 1
		));
		$opts = array(
			'http' =>
			array(
				'method'  => 'POST',
				'timeout' => 5000,
				'Content-Type' => 'application/json',
				'accept' => 'application/json',
				'authorization' => 'Basic ' . base64_encode(self::$username . ':' . self::$password),
				'content' => $postdata,
			)
		);
		try {
			$context  = stream_context_create($opts);
			$api_response = file_get_contents('https://RayganSMS.com/SendMessageWithPost.ashx', false, $context);
			self::check_send_otp($api_response);
			if (intval($api_response) > 2000) return true;
			else return false;
		} catch (Shahr_Log_Exception $e) {
			return false;
		}
	}
	private static  function check_send_otp($response)
	{
		if (intval($response) > 2000) {
			$value = array(
				'time' => time(),
				'otp' => self::$otp,
				'valid' => true,
				'ticket' => 1,
			);
			return update_user_meta((int)self::$user, 'user_otp', serialize($value));
		} else {
			return update_user_meta((int)self::$user, 'user_otp', serialize(array(serialize(false))));
		}
	}

	public static function authentication()
	{
		if (is_null(self::$user) || is_null(self::$input_otp) || is_null(self::$phone_number)) return false;
		$user_otp = unserialize(get_user_meta(self::$user, 'user_otp', true));
		if ($user_otp == false) return false;
		if (time() - (int)$user_otp['time'] > 3000) return false;
		if ((int)$user_otp['valid'] && (int)$user_otp['otp'] == (int)self::$input_otp) {
			$user_otp['valid'] = 0;
			update_user_meta(self::$user, 'user_otp', serialize($user_otp));
			return self::$user;
		}
		return false;
	}
	public function error_code()
	{
	}
	public static function int()
	{
		self::$username = strlen(Shahr_Log_Form_Handler::$otpSettings['OTP_user_name']) ? (string)Shahr_Log_Form_Handler::$otpSettings['OTP_user_name'] : null;
		self::$password = strlen(Shahr_Log_Form_Handler::$otpSettings['OTP_password']) ? (string)Shahr_Log_Form_Handler::$otpSettings['OTP_password'] : null;
		self::$otp_number = strlen(Shahr_Log_Form_Handler::$otpSettings['OTP_number']) ? (string)Shahr_Log_Form_Handler::$otpSettings['OTP_number'] : null;
		self::$number_of = strlen(Shahr_Log_Form_Handler::$otpSettings['OTP_number_of_authentication']) ? (string)Shahr_Log_Form_Handler::$otpSettings['OTP_number_of_authentication'] : null;
		self::$message = strlen(Shahr_Log_Form_Handler::$otpSettings['OTP_Message']) ? (string)Shahr_Log_Form_Handler::$otpSettings['OTP_Message'] : 'default';
		self::$input_otp = strlen($_POST['shahr-log-otp-code']) ? $_POST['shahr-log-otp-code'] : null;
	}
}
return $OTP = new shahr_log_raygansms();
