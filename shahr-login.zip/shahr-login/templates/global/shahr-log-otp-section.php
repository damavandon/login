<?php

/**
 * Login Form
 *
 * This template can be overridden by copying it to yourtheme/templates/shahr-login/global/shahr-log-login-section.php
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen.
 * @see     https://docs.wpshahr.com/shahr-login/
 * @version 2.1
 */

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$redirect 	= shahr_log_helper()->get_general_option('m-red-login');
$redirect 	= !empty($redirect) ? esc_attr($redirect) : $_SERVER['REQUEST_URI'];

$fields = array(
	'shahr-log-otp-username' => array(
		'input_type' 		=> 'text',
		'icon' 				=> 'far fa-user',
		'placeholder' 		=> __('Phone Number / Email', 'shahr-login'),
		'cont_class' 		=> array('shahr-log-aff-group'),
		'required' 			=> 'yes',
	),
	'shahr-log-otp-password' => array(
		'input_type' 	=> 'password',
		'icon' 			=> 'fas fa-key',
		'placeholder' 	=> __('Password', 'shahr-login'),
		'cont_class' 	=> array('shahr-log-aff-group', 'shahr-log-password-otp-hidden'),
		'required' 		=> 'no',
	),

);

$fields = apply_filters('shahr_log_login_fields', $fields, $args);
foreach ($fields as $field_id => $field_args) {
	shahr_log()->aff->fields->get_input_html($field_id, $field_args);
}
?>
<div class="shahr-log-aff-group shahr-log-code-otp-hidden shahr-log-otp-code_cont" style="flex-direction: column;" id="otp_input_id">
	<input type="text" name="shahr-log-otp-code" id="pinwrapper">
	<button type="button" class="button btn shahr-log-action-btn shahr-log-login-btn shahr-log-password-otp-hidden" style="width:31% ;padding-bottom:30px !important ; font-size:10px !important ;    display: unset !important; margin: 5px 34% !important ; padding: 20px 25px; border-radius:40px" name="shahr_log_otp_send_again" id="shahr_log_otp_send_again_id" style=""><?php _e('Send again', 'shahr-login') ?></button>
</div>
<!-- <div class="shahr-log-aff-group shahr-log-login-btm-fields">
	<a class="shahr-log-lostpw-tgr"><?php _e('Forgot Password?', 'shahr-login');  ?></a>
</div> -->
<?php do_action('shahr_log_login_add_fields', $args); ?>
<input type="hidden" id="shahr_log_form_id" name="_shahr_log_form" value="otp">
<input type="hidden" id="otp_userid_id" name="otp_userid" value="">
<button type="submit" class="button btn shahr-log-action-btn shahr-log-login-btn" <?php if (!shahr_log_is_limit_login_ok()) echo "disabled"; ?>><?php printf( __('ورود یا ثبت نام', 'shahr-login'),$sch='/') ; ?></button>
<a class=" shahr-log-password-otp-hidden" name="shahr_log_otp_send" id="shahr_log_otp_send_id" style=" text-align:right ; float:right ; padding-right: 20px"><?php _e('Login with OTP', 'shahr-login') ?></a>
<a class=" shahr-log-password-otp-hidden" name="shahr_log_otp_change_action" id="shahr_log_otp_change_action_id" style=" text-align:right ; float:right ; padding-right: 20px "><?php _e('Login with Password', 'shahr-login') ?></a>
<a class=" shahr-log-password-otp-hidden" name="shahr_log_otp_change_action" id="shahr_log_otp_change_username" style=" text-align:right ; float:left ; padding-right: 20px "><?php _e('Change email/phone', 'shahr-login') ?></a>
<input type="hidden" name="shahr_log_redirect" value="<?php echo $redirect; ?>">