<?php
/**
 * Lost Password Form
 *
 * This template can be overridden by copying it to yourtheme/templates/shahr-login/global/shahr-log-lostpw-section.php
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen.
 * @see     https://docs.wpshahr.com/shahr-login/
 * @version 2.1
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$fields = array(
	'shahr-log-rp-pass' => array(
		'input_type' 		=> 'password',
		'icon' 				=> 'fas fa-key',
		'placeholder' 		=> __( 'New Password', 'shahr-login' ),
		'cont_class' 		=> array( 'shahr-log-aff-group' ),
		'required' 			=> 'yes',
	),
	'shahr-log-rp-pass-again' => array(
		'input_type' 	=> 'password',
		'icon' 			=> 'fas fa-key',
		'placeholder' 	=> __( 'Confirm Password', 'shahr-login' ),
		'cont_class' 	=> array( 'shahr-log-aff-group', ),
		'required' 		=> 'yes'
	),
);

$regPasswordSettings = shahr_log()->aff->fields->get_field_data( 'shahr_log_reg_pass' )['settings'];

if( isset( $regPasswordSettings['strength_meter'] ) && $regPasswordSettings['strength_meter'] === "yes" ){
	$fields['shahr-log-rp-pass']['custom_attributes'] = array(
		'check_strength' 	=> 'yes',
		'strength_pass' 	=> $regPasswordSettings['strength_meter_pass']
	);
}

$fields['shahr-log-rp-pass']['minlength'] = $regPasswordSettings['minlength'];
$fields['shahr-log-rp-pass']['maxlength'] = $regPasswordSettings['maxlength'];

$fields = apply_filters( 'shahr_log_resetpw_fields', $fields, $args );

$resetpw_args = $args['forms']['resetpw']; 

?>

<?php do_action('shahr_log_resetpassword_form_start'); ?>

<?php if( !isset( $resetpw_args['user'] ) || is_wp_error( $resetpw_args['user'] ) ): ?>

	<span class="shahr-log-form-txt"><?php _e( 'This key is invalid or has already been used. Please reset your password again if needed.', 'shahr-login' ); ?></span>

<?php else: ?>

	<span class="shahr-log-form-txt"><?php _e( 'Please enter a new password', 'shahr-login' ); ?></span>

	<?php

	foreach ( $fields as $field_id => $field_args ) {
		shahr_log()->aff->fields->get_input_html( $field_id, $field_args );
	}

	?>

	<input type="hidden" name="rp_login" value="<?php echo $resetpw_args['rp_login'] ?>">

	<input type="hidden" name="rp_key" value="<?php echo $resetpw_args['rp_key'] ?>">

	<input type="hidden" name="_shahr_log_form" value="resetPassword">

	<input type="hidden" name="shahr-log-resetpw-nonce-field" value="<?php echo wp_create_nonce( 'shahr-log-resetpw-nonce' ); ?>">

	<?php do_action( 'shahr_log_resetpw_add_fields', $args ); ?>

	<button type="submit" class="button btn shahr-log-action-btn shahr-log-resetpw-btn"><?php _e( 'Change Password', 'shahr-login' ); ?></button>

<?php endif; ?>
