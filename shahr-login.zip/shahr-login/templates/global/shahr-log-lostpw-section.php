<?php
/**
 * Lost Password Form
 *
 * This template can be overridden by copying it to yourtheme/templates/shahr-login/global/shahr-log-lostpw-section.php
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen.
 * @see     https://docs.wpshahr.com/shahr-login/
 * @version 2.1
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


$fields = array(
	'user_login' => array(
		'input_type' 	=> 'text',
		'icon' 			=> 'fas fa-key',
		'placeholder' 	=> __( 'Username / Email', 'shahr-login' ),
		'cont_class' 	=> array( 'shahr-log-aff-group' ),
		'required' 		=> 'yes'
	),
);

$fields = apply_filters( 'shahr_log_lostpw_fields', $fields, $args );

?>


<span class="shahr-log-form-txt"><?php _e('Lost your password? Please enter your username or email address. You will receive a link to create a new password via email.','shahr-login'); ?></span>

<?php

foreach ( $fields as $field_id => $field_args ) {
	shahr_log()->aff->fields->get_input_html( $field_id, $field_args );
}

?>

<?php do_action( 'shahr_log_lostpw_add_fields', $args ); ?>

<input type="hidden" name="_shahr_log_form" value="lostPassword">

<?php wp_referer_field(); ?>

<button type="submit" class="button btn shahr-log-action-btn shahr-log-lostpw-btn"><?php _e('Email Reset Link','shahr-login'); ?></button>