<?php
/**
 * Registration Form
 *
 * This template can be overridden by copying it to yourtheme/templates/shahr-login/global/shahr-log-register-section.php
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen.
 * @see     https://docs.wpshahr.com/shahr-login/
 * @version 2.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$redirect 	= shahr_log_helper()->get_general_option( 'm-red-register' );
$redirect 	= !empty( $redirect ) ? esc_attr( $redirect ) : $_SERVER['REQUEST_URI'];

?>

<?php shahr_log()->aff->fields->get_fields_layout(); ?>

<input type="hidden" name="_shahr_log_form" value="register">

<?php do_action( 'shahr_log_register_add_fields', $args ); ?>

<button type="submit" class="button btn shahr-log-action-btn shahr-log-register-btn"><?php _e('Sign Up','shahr-login'); ?></button>

<input type="hidden" name="shahr_log_redirect" value="<?php echo $redirect; ?>">