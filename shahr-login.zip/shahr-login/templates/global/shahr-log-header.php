<?php
/**
 * Contains Header HTML for switching tabs.
 *
 * This template can be overridden by copying it to yourtheme/templates/shahr-login/global/shahr-log-header.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen.
 * @see     https://docs.wpshahr.com/shahr-login/
 * @version 2.1
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$register_args 	= $args['forms']['register'];
$form_active 	= $args['form_active'];
if($form_active=='otp')return;
?>

<div class="shahr-log-header">

	<ul class="shahr-log-tabs">
		<li data-tab="login" class="shahr-log-login-tgr"><?php _e( 'Login', 'shahr-login' ); ?></li>
		<?php if( isset( $register_args['enable'] ) && $register_args['enable'] === "yes" ): ?> 
			<li data-tab="register" class="shahr-log-reg-tgr"><?php _e( 'Sign Up', 'shahr-login' ); ?></li>
		<?php endif; ?>
	</ul>
</div>