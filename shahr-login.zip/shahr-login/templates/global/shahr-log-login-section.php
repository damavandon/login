<?php
/**
 * Login Form
 *
 * This template can be overridden by copying it to yourtheme/templates/shahr-login/global/shahr-log-login-section.php
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen.
 * @see     https://docs.wpshahr.com/shahr-login/
 * @version 2.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$redirect 	= shahr_log_helper()->get_general_option( 'm-red-login' );
$redirect 	= !empty( $redirect ) ? esc_attr( $redirect ) : $_SERVER['REQUEST_URI'];

$fields = array(
	'shahr-log-username' => array(
		'input_type' 		=> 'text',
		'icon' 				=> 'far fa-user',
		'placeholder' 		=> __( 'Username / Email', 'shahr-login' ),
		'cont_class' 		=> array( 'shahr-log-aff-group' ),
		'required' 			=> 'yes',
		'autocomplete' => 'email'
	),

	'shahr-log-password' => array(
		'input_type' 	=> 'password',
		'icon' 			=> 'fas fa-key',
		'placeholder' 	=> __( 'Password', 'shahr-login' ),
		'cont_class' 	=> array( 'shahr-log-aff-group' ),
		'required' 		=> 'yes'
	),
);

$fields = apply_filters( 'shahr_log_login_fields', $fields, $args );

foreach ( $fields as $field_id => $field_args ) {
	shahr_log()->aff->fields->get_input_html( $field_id, $field_args );
}

?>

<div class="shahr-log-aff-group shahr-log-login-btm-fields">
	<label class="shahr-log-form-label">
		<input type="checkbox" name="shahr-log-rememberme" value="forever" />
		<span><?php _e( 'Remember me', 'shahr-login' ); ?></span>
	</label>
	<a class="shahr-log-lostpw-tgr"><?php _e('Forgot Password?','shahr-login'); ?></a>
</div>

<?php do_action( 'shahr_log_login_add_fields', $args ); ?>

<input type="hidden" name="_shahr_log_form" value="login">

<button type="submit" class="button btn shahr-log-action-btn shahr-log-login-btn" <?php if( !shahr_log_is_limit_login_ok() ) echo "disabled"; ?>><?php _e('Sign In','shahr-login'); ?></button>

<input type="hidden" name="shahr_log_redirect" value="<?php echo $redirect; ?>">