<?php

/**
 * The template is for popup design
 *
 * This template can be overridden by copying it to yourtheme/templates/shahr-login/shahr-log-popup.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen.
 * @see     https://docs.wpshahr.com/shahr-login/
 * @version 2.1
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}


?>

<div class="shahr-log-container" style="visibility: hidden;">
    <div class="shahr-log-opac"></div>
    <div class="shahr-log-modal">

        <div class="shahr-log-inmodal">
            <span class="shahr-log-close shahr-log-icon-cancel-circle"></span>
            <div class="shahr-log-wrap">
                <div class="logo-mobile" style=" margin: 10px ;">
                    <img width="140px" src="https://www.homestylee.com/wp-content/uploads/2019/01/photo_2018-08-16_10-45-561.jpg">
                </div>
                <div class="shahr-log-sidebar"></div>
                <div class="shahr-log-srcont">
                    <div class="shahr-log-main">
                        <?php
                        $args = array(
                            'form_class'    => 'shahr-log-form-popup',
                            'display'       => 'popup'
                        );
                        shahr_log_get_form($args)
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>