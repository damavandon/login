<?php
/**
 * Woocommerce login form is replaced by this template
 *
 * This template can be overridden by copying it to yourtheme/templates/shahr-log-wc-form-login.php.
 * @version 4.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

do_action( 'woocommerce_before_customer_login_form' ); ?>

<?php echo do_shortcode( apply_filters( 'shahr_log_myaccount_shortcode', '[shahr_log_inline_form active="login"]' ) ); ?>
		
<?php do_action( 'woocommerce_after_customer_login_form' ); ?>
