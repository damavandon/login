<?php
/**
 * The template is a form container
 *
 * This template can be overridden by copying it to yourtheme/templates/shahr-login/shahr-log-form.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen.
 * @see     https://docs.wpshahr.com/shahr-login/
 * @version 4.1
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$form_active = $args['form_active'];

?>

<div class="shahr-log-form-container shahr-log-form-<?php echo $args['display']; ?>" data-active="<?php echo $form_active; ?>">

	<?php if( $form_active === 'resetpw' && isset( $args['forms']['resetpw']['user'] ) && !is_wp_error( $args['forms']['resetpw']['user'] ) ): ?>
		<span class="shahr-log-resetpw-tgr shahr-log-resetpw-hnotice"><?php _e( 'Continue to resetting password', 'shahr-login' ); ?></span>
	<?php endif; ?>

	<?php do_action( 'shahr_log_before_header', $args ); ?>

	<?php shahr_log_helper()->get_template( 'global/shahr-log-header.php', array( 'args' => $args ) ); ?>

	<?php do_action( 'shahr_log_after_header', $args ); ?>

	<?php foreach ( $args['forms'] as $form => $form_args ): ?>

		<?php if( $form_args['enable'] !== 'yes' ) continue; ?>
	
		<div data-section="<?php echo $form ?>" class="shahr-log-section">

			<div class="shahr-log-fields">

				<?php do_action( 'shahr_log_before_form', $form, $args ); ?>

				<form class="shahr-log-action-form shahr-log-form-<?php echo $form; ?>">

					<?php do_action( 'shahr_log_form_start', $form, $args ); ?>

					<?php shahr_log_helper()->get_template( 'global/shahr-log-'.$form.'-section.php', array( 'args' => $args ) ); ?>

					<?php do_action( 'shahr_log_form_end', $form, $args ); ?>

				</form>

				<?php do_action( 'shahr_log_after_form', $form, $form_args ); ?>

			</div>

		</div>

	<?php endforeach; ?>

	<?php do_action( 'shahr_log_container_end', $args ); ?>

</div>