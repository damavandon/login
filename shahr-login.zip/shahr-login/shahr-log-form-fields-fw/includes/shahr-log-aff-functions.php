<?php

//Get tempalte
if( !function_exists( 'shahr_log_aff_get_template' ) ){
	function shahr_log_aff_get_template ( $template_name, $path = '', $args = array(), $return = false ) {

	    $located = shahr_log_aff_locate_template ( $template_name, $path );

	    if ( $args && is_array ( $args ) ) {
	        extract ( $args );
	    }

	    if ( $return ) {
	        ob_start ();
	    }

	    // include file located
	    if ( file_exists ( $located ) ) {
	        include ( $located );
	    }

	    if ( $return ) {
	        return ob_get_clean ();
	    }


	}
}

//Locate template
if( !function_exists( 'shahr_log_aff_locate_template' ) ){
	function shahr_log_aff_locate_template ( $template_name, $template_path ) {

	    // Look within passed path within the theme - this is priority.
	    $located = '';

		$template_names = array(
			'templates/' . $template_name,
			$template_name,
		);

		foreach ( (array) $template_names as $template_name ) {
	        if ( !$template_name )
	            continue;
	        if ( file_exists('STYLESHEETPATH '. '/' . $template_name)) {
	            $located = 'STYLESHEETPATH' . '/' . $template_name;
	            break;
	        } elseif ( file_exists('TEMPLATEPATH' . '/' . $template_name) ) {
	            $located = 'TEMPLATEPATH' . '/' . $template_name;
	            break;
	        } elseif ( file_exists( ABSPATH . WPINC . '/theme-compat/' . $template_name ) ) {
	            $located = ABSPATH . WPINC . '/theme-compat/' . $template_name;
	            break;
	        }
	    }
	 
	    if ( '' != $located )
	        load_template( $located, $require_once );
	 
	    $template =  $located;

		//Check woocommerce directory for older version
		if( !$template && class_exists( 'woocommerce' ) ){
			if( file_exists( WC()->plugin_path() . '/templates/' . $template_name ) ){
				$template = WC()->plugin_path() . '/templates/' . $template_name;
			}
		}

		if( !$template & file_exists( dirname( SHAHR_LOG_AFF_DIR ). '/templates/' . $template_name ) ){
			$template = dirname( SHAHR_LOG_AFF_DIR ). '/templates/' . $template_name;
		}

	    if ( ! $template ) {
	        $template = trailingslashit( $template_path ) . $template_name;
	    }

	    return $template;
	}
}

?>