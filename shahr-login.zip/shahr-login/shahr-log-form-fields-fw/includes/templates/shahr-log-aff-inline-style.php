<?php

$iconbgcolor 	= esc_html( $sy_options['s-icon-bgcolor'] );
$iconcolor 		= esc_html( $sy_options['s-icon-color'] );
$iconsize 		= esc_html( $sy_options['s-icon-size'] );
$iconwidth 		= esc_html( $sy_options['s-icon-width'] );
$iconborcolor	= esc_html( $sy_options['s-icon-borcolor'] );
$fieldmargin 	= esc_html( $sy_options['s-field-bmargin'] );
$inputbgcolor 	= esc_html( $sy_options['s-input-bgcolor'] );
$inputtxtcolor 	= esc_html( $sy_options['s-input-txtcolor'] );
$focusbgcolor 	= esc_html( $sy_options['s-input-focusbgcolor'] );
$focustxtcolor 	= esc_html( $sy_options['s-input-focustxtcolor'] );

?>

.shahr-log-aff-input-group .shahr-log-aff-input-icon{
	background-color: <?php echo $iconbgcolor ?>;
	color: <?php echo $iconcolor ?>;
	max-width: <?php echo $iconwidth ?>px;
	min-width: <?php echo $iconwidth ?>px;
	border: 1px solid <?php echo $iconborcolor ?>;
	border-right: 0;
	font-size: <?php echo $iconsize ?>px;
}
.shahr-log-aff-group{
	margin-bottom: <?php echo $fieldmargin ?>px;
}

.shahr-log-aff-group input[type="text"], .shahr-log-aff-group input[type="password"], .shahr-log-aff-group input[type="email"], .shahr-log-aff-group input[type="number"], .shahr-log-aff-group select, .shahr-log-aff-group select + .select2{
	background-color: <?php echo $inputbgcolor ?>;
	color: <?php echo $inputtxtcolor ?>;
}

.shahr-log-aff-group input[type="text"]::placeholder, .shahr-log-aff-group input[type="password"]::placeholder, .shahr-log-aff-group input[type="email"]::placeholder, .shahr-log-aff-group input[type="number"]::placeholder, .shahr-log-aff-group select::placeholder{
	color: <?php echo $inputtxtcolor ?>;
	opacity: 0.7;
}

.shahr-log-aff-group input[type="text"]:focus, .shahr-log-aff-group input[type="password"]:focus, .shahr-log-aff-group input[type="email"]:focus, .shahr-log-aff-group input[type="number"]:focus, .shahr-log-aff-group select:focus, .shahr-log-aff-group select + .select2:focus{
	background-color: <?php echo $focusbgcolor ?>;
	color: <?php echo $focustxtcolor ?>;
}


<?php if( $sy_options['s-show-icons'] !== "yes" ): ?>

	.shahr-log-aff-input-group .shahr-log-aff-input-icon{
		display: none!important;
	}

<?php else: ?>

	.shahr-log-aff-group input[type="text"], .shahr-log-aff-group input[type="password"], .shahr-log-aff-group input[type="email"], .shahr-log-aff-group input[type="number"], .shahr-log-aff-group select{
	}

<?php endif; ?>