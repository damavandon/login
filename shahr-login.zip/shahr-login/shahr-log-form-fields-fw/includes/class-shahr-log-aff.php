<?php

class Shahr_Log_Aff{

	public $plugin_slug, $admin_page_slug, $fields, $admin;

	public function __construct( $plugin_slug, $admin_page_slug ){

		$this->plugin_slug = $plugin_slug;
		$this->admin_page_slug = $admin_page_slug;

		$this->includes();
		$this->hooks();
		$this->init();
		
	}

	public function hooks(){
		add_action( 'init', array( $this, 'on_install' ), 1 );
	}

	public function includes(){

		include_once SHAHR_LOG_AFF_DIR.'/includes/shahr-log-aff-functions.php';
		include_once SHAHR_LOG_AFF_DIR.'/admin/class-shahr-log-aff-fields.php';
		include_once SHAHR_LOG_AFF_DIR.'/admin/class-shahr-log-aff-admin.php';

	}

	public function init(){

		$this->fields 		= new Shahr_Log_Aff_Fields( $this );
		$this->admin 		= new Shahr_Log_Aff_Admin( $this );
		
	}


	public function is_fields_page(){
		return is_admin() && isset( $_GET['page'] ) && $_GET['page'] === $this->admin_page_slug;
	}


	public function is_fields_page_ajax_request(){
		return isset( $_POST['plugin_info'] ) && $_POST['plugin_info']['admin_page_slug'] === $this->admin_page_slug;
	}


	//Enqueue scripts from the main plugin
	public function enqueue_scripts(){

		$sy_options 	= get_option( $this->admin->settings->get_option_key( 'general' ) );

		wp_enqueue_style( 'shahr-log-aff-style',SHAHR_LOG_AFF_URL.'/assets/css/shahr-log-aff-style.css', array(),SHAHR_LOG_AFF_VERSION) ;

		if( $sy_options['s-show-icons'] === "yes" ){
			wp_enqueue_style( 'shahr-log-aff-font-awesome5', 'https://use.fontawesome.com/releases/v5.5.0/css/all.css' );
		}


		$fields = $this->fields->get_fields_data();

		$has_date = $has_meter = false;

		if( !empty( $fields ) ){

			foreach ( $fields as $field_id => $field_data) {

				if( !isset( $field_data['input_type'] ) ) continue;

				switch ( $field_data['input_type'] ) {
					case 'date':
						$has_date = true;
						break;

					case 'password':
						if( isset( $field_data['settings']['strength_meter'] ) && $field_data['settings']['strength_meter'] === "yes" ){
							$has_meter = true;
						}
						break;
				}

			}

		}

		if( $has_meter ){
			wp_enqueue_script( 'password-strength-meter' );
		}

		if( $has_date ){
			wp_enqueue_style( 'jquery-ui-css', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css' );
			wp_enqueue_script('jquery-ui-datepicker');
		}

		if( !wp_style_is( 'select2' ) ){
			wp_enqueue_style( 'select2', "https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" );
		}

		if( !wp_script_is( 'select2' ) ){
			wp_enqueue_script( 'select2', "https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js", array('jquery'),SHAHR_LOG_AFF_VERSION, true ); // Main JS
		}

		wp_enqueue_script( 'shahr-log-aff-js',SHAHR_LOG_AFF_URL.'/assets/js/shahr-log-aff-js.js', array( 'jquery' ),SHAHR_LOG_AFF_VERSION, true );
		wp_localize_script('shahr-log-aff-js','shahr_log_aff_localize',array(
			'adminurl'  			=> admin_url().'admin-ajax.php',
			'countries' 			=> json_encode( include SHAHR_LOG_AFF_DIR.'/countries/countries.php' ),
			'states' 				=> json_encode( include SHAHR_LOG_AFF_DIR.'/countries/states.php' ),
			'password_strength' 	=> array(
				'min_password_strength' => apply_filters( 'shahr_log_aff_min_password_strength', 3 ),
				'i18n_password_error'   => esc_attr__( 'Please enter a stronger password.', $this->plugin_slug ),
				'i18n_password_hint'    => esc_attr( wp_get_password_hint() ),
			)
		));

		$inline_style = shahr_log_aff_get_template( 'shahr-log-aff-inline-style.php',  SHAHR_LOG_AFF_DIR.'/includes/templates/', array( 'sy_options' => $sy_options ), true );

		wp_add_inline_style( 'shahr-log-aff-style', $inline_style );

	}


	/**
	 * What type of request is this?
	 *
	 * @param  string $type admin, ajax, cron or frontend.
	 * @return bool
	 */
	private function is_request( $type ) {
		switch ( $type ) {
			case 'admin':
				return is_admin();
			case 'ajax':
				return defined( 'DOING_AJAX' );
			case 'cron':
				return defined( 'DOING_CRON' );
			case 'frontend':
				return ( ! is_admin() || defined( 'DOING_AJAX' ) ) && ! defined( 'DOING_CRON' );
		}
	}


	public function on_install(){

		$db_version = get_option( 'shahr_log_aff_'.$this->plugin_slug.'_version' );
		
		if( version_compare( $db_version,SHAHR_LOG_AFF_VERSION , '<' ) ){
			$this->fields->set_defaults();
			update_option( 'shahr_log_aff_'.$this->plugin_slug.'_version',SHAHR_LOG_AFF_VERSION );
		}
	}

}


?>