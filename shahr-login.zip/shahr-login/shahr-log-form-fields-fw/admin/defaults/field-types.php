<?php

//array( 'id', 'type', Title', extra args = array() )
$field_types =  array(
	'shahr_log_aff_text' => array(
		'shahr_log_aff_text',
		'text',
		'Text',
		array(
			'icon' => 'fas fa-font',
		)
	),

	'shahr_log_aff_textarea' => array(
		'shahr_log_aff_textarea',
		'textarea',
		'Text Area',
		array(
			'icon' => 'fas fa-font',
		)
	),
	'shahr_log_aff_number' => array(
		'shahr_log_aff_number',
		'number',
		'Number',
		array(
			'icon' => 'fas fa-sort-numeric-up',
		)
	),
	'shahr_log_aff_date' => array('shahr_log_aff_date',
		'date',
		'Date',
		array(
			'icon' => 'far fa-calendar-alt'
		),
	),
	'shahr_log_aff_checkbox_single' => array(
		'shahr_log_aff_checkbox_single',
		'checkbox_single',
		'Checkbox',
		array(
			'icon' => 'fas fa-check-square'
		)
	),
	'shahr_log_aff_checkbox_list' => array(
		'shahr_log_aff_checkbox_list',
		'checkbox_list',
		'Checkbox List',
		array(
			'icon' => 'fas fa-list-ul',
		)
	),
	'shahr_log_aff_radio' => array(
		'shahr_log_aff_radio',
		'radio', 'Radio List',
		array(
			'icon' => 'fas fa-dot-circle'
		)
	),
	'shahr_log_aff_select_list' => array(
		'shahr_log_aff_select_list',
		'select_list',
		'Select',
		array(
			'icon' => 'fas fa-angle-down',
		)
	),
	'shahr_log_aff_email' => array(
		'shahr_log_aff_email',
		'email',
		'Email',
		array(
			'icon' => 'fas fa-at',
		)
	),
	'shahr_log_aff_country' => array(
		'shahr_log_aff_country',
		'country',
		'Country',
		array(
			'icon' => 'fas fa-globe',
		)
	),
	'shahr_log_aff_states' => array(
		'shahr_log_aff_states',
		'states',
		'States',
		array(
			'icon' => 'fas fa-map-marker'
		)
	),
	'shahr_log_aff_phone_code' => array(
		'shahr_log_aff_phone_code',
		'phone_code',
		'Phone Code',
		array(
			'icon' => 'fas fa-code',
		)
	),
	'shahr_log_aff_phone' => array(
		'shahr_log_aff_phone',
		'phone',
		'Phone',
		array(
			'icon' => 'fas fa-phone',
		)
	),

	'shahr_log_aff_password' => array(
		'shahr_log_aff_password',
		'password',
		'Password',
		array(
			'icon' => 'fas fa-key',
		)
	),
);


return apply_filters( 'shahr_log_aff_'.$this->plugin_slug.'_default_field_types', $field_types );