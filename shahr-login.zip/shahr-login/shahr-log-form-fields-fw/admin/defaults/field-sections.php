<?php

return array(
	'basic' => array(
		'basic',
		'Basic Settings',
		array(
			'priority' => 10
		),
	),
	'advanced' => array(
 		'advanced',
 		'Advanced Settings',
 		array(
			'priority' => 20
		)
	)
);

?>