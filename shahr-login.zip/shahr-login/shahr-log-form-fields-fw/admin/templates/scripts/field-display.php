<li class="shahr-log-aff-fs-display shahr-log-aff-fsd-{{data.type_data.type}} {{{ ( data.type_data.can_delete !== 'yes'  ) ? 'shahr-log-aff-locked-field' : '' }}}" id="{{data.field_id}}" data-type="{{data.type_data.type}}">
	<div class="shahr-log-aff-label shahr-log-aff-label-{{data.type_data.type}}">
		<span class="shahr-log-aff-type-icon {{data.type_data.icon}}"></span>
		<span>{{data.type_data.title}}</span>
		<span></span>
	</div>
	<div class="shahr-log-aff-fsd-cta">
		<# if ( data.type_data.can_delete === "yes" ) { #>
			<span class="shahr-log-aff-fsd-cta-del fas fa-trash"></span>	
		<# } else { #>
			<span class="fas fa-lock"></span>
        <# } #>
		
	</div>
</li>