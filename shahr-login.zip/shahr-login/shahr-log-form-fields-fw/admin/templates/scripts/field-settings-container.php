<form class="shahr-log-aff-field-settings shahr-log-aff-fs-{{data.type_data.type}}" id="{{data.field_id}}">
	<div class="shahr-log-aff-label shahr-log-aff-label-{{data.type_data.type}}">
		<span class="shahr-log-aff-type-icon {{data.type_data.icon}}"></span>
		<span>{{data.type_data.title}}</span>
		<span></span>
	</div>
	<div class="shahr-log-aff-fs-wrap">{{{data.fields_html}}}</div>
</form>