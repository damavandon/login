<?php

$countries = include SHAHR_LOG_AFF_DIR.'/countries/countries.php';

?>
<# if ( "section" === data.type ) { #>
<div class="shahr-log-aff-field-section shahr-log-aff-field-section-{{data.id}}">
	<label class="shahr-log-aff-section-label">{{data.title}}</label>
	<div>
<# }else{ #>	
	
<div class="shahr-log-aff-setting-{{data.type}} shahr-log-aff-setting-{{data.id}} shahr-log-aff-fs-{{data.width}} shahr-log-aff-fs-input {{{ ( data.required && data.required === 'yes' ) ? 'shahr-log-aff-required' : '' }}}" data-id="{{data.id}}">
	<label for="shahr_log_aff_{{data.id}}">{{data.title}}
		<# if ( data.info ) { #>
		<div class="shahr-log-aff-info">
			<span class="shahr-log-aff-info-icon fas fa-info-circle"></span>
			<span class="shahr-log-aff-infotext">{{data.info}}</span>
		</div>
		<# } #>
	</label>

	<# if ( "text" === data.type ) { #>
		<input type="text" id="shahr_log_aff_{{data.id}}" name="shahr_log_aff_{{data.id}}" placeholder="{{data.placeholder}}" value="{{data.value}}" class="{{data.class}}" {{data.disabled}}>
	<# } #>

	<# if ( "checkbox" === data.type ) { #>
		<label for="shahr_log_aff_{{data.id}}" class="shahr-log-aff-switch">
		  <input type="checkbox" id="shahr_log_aff_{{data.id}}" name="shahr_log_aff_{{data.id}}" value="yes" {{data.disabled}} {{{ ( data.value === 'yes' ) ? 'checked' : '' }}} >
		  <span class="shahr-log-aff-slider"></span>
		</label>
	<# } #>

	<# if ( "number" === data.type ) { #>
		<input type="number" id="shahr_log_aff_{{data.id}}" name="shahr_log_aff_{{data.id}}" min="{{data.minlength}}" placeholder="{{data.placeholder}}" class="{{data.class}}" value="{{data.value}}">
	<# } #>


	<# if ( "iconpicker" === data.type ) { #>
		<input type="text" class="shahr-log-aff-iconpicker" name="shahr_log_aff_{{data.id}}" id="shahr_log_aff_{{data.id}}" placeholder="{{data.placeholder}}" class="{{data.class}}" value="{{data.value}}" autocomplete="off">
	<# } #>

	<# if ( "date" === data.type ) { #>
		<input type="text" class="shahr-log-aff-datepicker" name="shahr_log_aff_{{data.id}}" id="shahr_log_aff_{{data.id}}" placeholder="{{data.placeholder}}" class="{{data.class}}" value="{{data.value}}" autocomplete="off">
	<# } #>

	<# if ( "select" === data.type ) { #>
		<select id="shahr_log_aff_{{data.id}}" class="{{data.class}}" name="shahr_log_aff_{{data.id}}">
			<# _.each( data.options , function(option_title, option_value) { #>
				<option value="{{option_value}}" {{{ ( data.value === option_value ) ? 'selected="selected"' : '' }}} >{{option_title}}</option>
			<# }) #>
		</select>
	<# } #>

	<# if ( "checkbox_list" === data.type || "radio" === data.type || "select_list" === data.type || "checkbox_single" === data.type ) { #>
		<div class="shahr-log-aff-multiple-options" id="shahr_log_aff_{{data.id}}">
			<button class="shahr-log-add-option"><span class="fas fa-plus-circle"></span></button>
			<ul class="shahr-log-aff-options-list">
				<# _.each( data.value , function(option, index) { #>
					<li class="shahr-log-aff-opt">
						<span class="fas fa-bars"></span>

						<# if ( "checkbox_list" === data.type || "checkbox_single" === data.type ) { #>
							<input type="checkbox" {{option.checked}} class="option-check">
						<# } #>

						<# if ( "radio" === data.type || "select_list" === data.type ) { #>
							<input type="radio" name="shahr_log_aff_radio_single" {{option.checked}} class="option-check">
						<# } #>

						<input type="text" value="{{option.label}}" class="mcb-label" placeholder="Label">
						<input type="text" value="{{option.value}}" class="mcb-value" placeholder="Value">
						<span class="mcb-del fas fa-minus-circle"></span>
					</li>
				<# }) #>
			</ul>
			<input type="hidden" class="shahr-log-aff-trigger-change" id="shahr_log_aff_{{data.id}}" name="shahr_log_aff_{{data.id}}">
		</div>
	<# } #>


	<# if ( "select_multiple" === data.type) { #>
		
		<div class="shahr-log-aff-select-multiple-container">
			<select multiple id="shahr_log_aff_{{data.id}}" class="shahr-log-aff-select-multiple" style="display: none;">
				<# _.each( data.options , function(option_title, option_value) { #>
					<option value="{{option_value}}" class="{{ data.value[option_value] && (data.value[option_value]).checked === 'checked' ? 'aff-default' : '' }}" {{ data.value[option_value] ? 'selected=selected' : '' }}>{{option_title}}</option>
				<# }) #>
			</select>

			<div class="shahr-log-aff-select-multiple-textarea">
				<ul>
					<# _.each( data.value , function(option_data, option_value) { #>
					<li data-value={{option_value}} class="{{option_data.checked === 'checked' ? 'aff-default' : ''}}"><span class="shahr-log-aff-sel-remove dashicons dashicons-no-alt"></span>{{option_data.label}}</li>
					<# }) #>
				</ul>
			</div>

			<ul class="shahr-log-aff-multiple-list">
				<# _.each( data.options , function(option_title, option_value) { #>
					<li data-value="{{option_value}}">{{option_title}}</li>
				<# }) #>
			</ul>
			<input type="hidden" class="shahr-log-aff-trigger-change" id="shahr_log_aff_{{data.id}}" name="shahr_log_aff_{{data.id}}">
		</div>
	<# } #>
</div>
<# } #>	

<# if ( "section" === data.type ) { #>
	</div>
</div>
<# } #>	