<div class="shahr-log-tabs">
	<?php

	$current_tab = isset( $_GET['tab'] ) ? $_GET['tab'] : 'fields';

	echo '<h2 class="nav-tab-wrapper">';
	foreach ( $tabs as $tab_id => $tab_data ) {
		$active = $current_tab == $tab_id ? 'nav-tab-active' : '';
		echo '<a class="nav-tab ' . $active . '" href="?page='. $admin_page_slug .'&tab=' . $tab_id . '">' . $tab_data['title'] . '</a>';	
	}
	echo '</h2>';

	$option_name = $aff->admin->settings->get_option_key( $current_tab );

	?>
</div>

<div class="shahr-log-aff-container">

	<?php do_action( 'shahr_log_aff_admin_page_display_start', $admin_page_slug ); ?>

	<?php if( $current_tab === 'fields' ): ?>
		<?php $aff->admin->display_layout(); ?>
	<?php else: ?>

	<div class="shahr-log-main">

			<form method="post" action="options.php" class="shahr-log-aff-<?php echo $current_tab; ?>-form-settings">
				<?php

					settings_fields( $option_name ); // Display Settings

					do_settings_sections( 'shahr-log-fields' ); // Display Sections

					submit_button( 'Save Settings' );	// Display Save Button
				?>			
			</form>

		<?php endif; ?>

	</div>


	<?php do_action( 'shahr_log_aff_admin_page_display_end', $admin_page_slug ); ?>

</div>

