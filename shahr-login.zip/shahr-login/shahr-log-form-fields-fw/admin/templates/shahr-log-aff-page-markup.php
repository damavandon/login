<div class="shahr-log-aff-settings-modal">

	<div class="shahr-log-aff-settings-topbar">
		<div class="shahr-log-aff-notice-holder"></div>
		<button class="shahr-log-aff-add-field"><span class="fas fa-plus-circle"></span>Add Field</button>
		<button id="shahr-log-aff-save"><span class="fas fa-save"></span>Save</button>
		<button class="shahr-log-aff-reset-field"><span class="fas fa-sync"></span>Reset</button>
	</div>
	
	<div class="shahr-log-aff-settings-container">
		<div class="shahr-log-aff-sidebar">
			<?php echo $sidebar_template; ?>
			<div class="shahr-log-aff-field-settings-container"></div>
		</div>

		<ul class="shahr-log-aff-main"></ul>
	</div>

</div>