<?php

class Shahr_Log_Aff_Admin{

	public $aff;

	public function __construct( Shahr_Log_Aff $aff ){
		$this->aff 		= $aff;
		$this->includes();
		$this->settings = new Shahr_Log_Aff_Settings( $aff );
		$this->hooks();
	}

	public function includes(){
		require_once SHAHR_LOG_AFF_DIR.'/admin/settings/class-shahr-log-aff-settings.php';
	}

	public function hooks(){
		if( !$this->aff->is_fields_page() ) return;
		add_action( 'admin_footer', array( $this, 'custom_admin_css') );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) ); 
		add_action( 'admin_footer', array( $this, 'templates') );
	}


	public function enqueue_scripts(){

		wp_enqueue_style( 'jquery-ui-css', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css' ); // Jquery UI CSS
		wp_enqueue_style( 'shahr-log-aff-fa', 'https://use.fontawesome.com/releases/v5.5.0/css/all.css' ); //Font Awesome
		wp_enqueue_style( 'shahr-log-aff-fa-picker',SHAHR_LOG_AFF_URL.'/lib/fontawesome-iconpicker/dist/css/fontawesome-iconpicker.min.css', array(),SHAHR_LOG_AFF_VERSION, 'all' ); //Font Awesome Icon Picker
		wp_enqueue_style( 'shahr-log-aff-admin-style',SHAHR_LOG_AFF_URL . '/admin/assets/css/shahr-log-aff-admin-style.css', array(),SHAHR_LOG_AFF_VERSION, 'all' );

		wp_enqueue_script('jquery-ui-datepicker');
		wp_enqueue_script('jquery-ui-selectable');
		wp_enqueue_script('jquery-ui-sortable');

		wp_enqueue_script( 'shahr-log-aff-fa-pickers',SHAHR_LOG_AFF_URL.'/lib/fontawesome-iconpicker/dist/js/fontawesome-iconpicker.js', array( 'jquery'),SHAHR_LOG_AFF_VERSION, false );

		wp_enqueue_script( 'shahr-log-aff-admin-js',SHAHR_LOG_AFF_URL . '/admin/assets/js/shahr-log-aff-admin-js.js', array( 'jquery','wp-color-picker', 'wp-util'),SHAHR_LOG_AFF_VERSION, false );
		wp_localize_script( 'shahr-log-aff-admin-js', 'shahr_log_aff_localize', array(
			'ajax_url' 		=> admin_url().'admin-ajax.php',
			'submit_nonce'	=> wp_create_nonce( 'shahr-log-aff-submit-nonce' ),
			'addField' 		=> apply_filters( 'shahr_log_aff_add_fields', true, $this->aff )
		));
	}


	public function templates(){
		include SHAHR_LOG_AFF_DIR.'/admin/templates/shahr-log-aff-template-scripts.php';
	}

	//Called by main plugin to display settings
	public function display_layout(){

		do_action( 'shahr_log_aff_before_displaying_fields' );

		$args = array(
			'sidebar_template' => shahr_log_aff_get_template( 'shahr-log-aff-field-selector.php',  SHAHR_LOG_AFF_DIR.'/admin/templates/', array(
				'field_types' 	=> $this->aff->fields->get_field_types(),
				'aff' 			=> $this->aff
			), true ),
		);
		shahr_log_aff_get_template( 'shahr-log-aff-page-markup.php',  SHAHR_LOG_AFF_DIR.'/admin/templates/', $args );
	}

	//Add css to admin footer
	public function custom_admin_css(){
		?>
		<style type="text/css">
			p.shahr-log-aff-description {font-style: italic;}

			.shahr-log-aff-input-group label {
			    display: block;
			    margin-bottom: 10px;
			}

			.shahr-log-aff-group input[type="checkbox"], .shahr-log-aff-group input[type="radio"] {
			    margin-right: 10px;
			}
		</style>
		<?php
	}



	public function display_page(){

		$tabs = array();

		$tabs['fields'] = array(
			'id' 	=> 'fields',
			'title' => 'Fields'
		);

		$tabs = array_merge( $tabs, $this->settings->tabs );

		$args = array(
			'tabs' 				=> $tabs,
			'admin_page_slug' 	=> $this->aff->admin_page_slug,
			'aff' 				=> $this->aff
		);
		shahr_log_helper()->get_template( "shahr-log-aff-page-display.php", $args, SHAHR_LOG_AFF_DIR.'/admin/templates/' );
	}

}


?>