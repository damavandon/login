<?php

if( !defined( 'SHAHR_LOG_AFF_DIR' ) ){
	define( 'SHAHR_LOG_AFF_DIR', dirname(__FILE__) );
}

if( !defined( 'SHAHR_LOG_AFF_URL' ) ){
	define( 'SHAHR_LOG_AFF_URL', plugins_url( '', __FILE__  ) );
}

if( !defined( 'SHAHR_LOG_AFF_VERSION' ) ){
	define( 'SHAHR_LOG_AFF_VERSION', '1' );
}

require_once SHAHR_LOG_AFF_DIR.'/includes/class-shahr-log-aff.php';

//Begin
if( !function_exists('shahr_log_aff_fire') ){
	function shahr_log_aff_fire( $plugin_slug, $admin_page_slug ){
		
		if( !$plugin_slug ) return;
		return new Shahr_Log_Aff( $plugin_slug, $admin_page_slug );
		do_action( 'shahr_log_aff_'.$plugin_slug.'_loaded' );
		
	}
}
?>