<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class Shahr_Log_Admin_Settings{

	protected static $_instance = null;

	public static function get_instance(){
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public function __construct(){
		$this->hooks();	
	}
	public function hooks(){

		if( current_user_can( 'manage_options' ) ){
			add_action( 'init', array( $this, 'generate_settings' ), 0 );
			add_action( 'admin_menu', array( $this, 'add_menu_pages' ) );
		}
		add_filter( 'plugin_action_links_' . SHAHR_LOG_PLUGIN_BASENAME, array( $this, 'plugin_action_links' ) );
		add_filter( 'shahr_log_aff_add_fields', array( $this,'add_new_fields' ), 10, 2 );
		add_action( 'admin_enqueue_scripts',array($this,'enqueue_scripts'));
		add_action( 'admin_footer', array( $this, 'inline_css' ) );
	}

	public function add_new_fields( $allow, $aff ){
	//	if( $aff->plugin_slug === 'shahr-login' ) return false;
		return $allow;
	}
	
	
	public function generate_settings(){
		shahr_log_helper()->admin->auto_generate_settings();
	}
	/**
	 * Show action links on the plugin screen.
	 *
	 * @param	mixed $links Plugin Action links
	 * @return	array
	 */
	public function plugin_action_links( $links ) {
		$action_links = array(
			'settings' 	=> '<a href="' . admin_url( 'admin.php?page=shahr-login-settings' ) . '">Settings</a>',
			'support' 	=> '<a href="https://shahrwp.com/support" target="__blank">Support</a>',
			'upgrade' 	=> '<a href="https://shahrwp.com/plugins/shahr-login" target="__blank">Upgrade</a>',
		);

		return array_merge( $action_links, $links );
	}

	public function enqueue_scripts($hook) {

		//Enqueue Styles only on plugin settings page
		if($hook != 'login-signup-popup_page_shahr-log-fields' && !shahr_log_helper()->admin->is_settings_page() ){
			return;
		}
		wp_enqueue_style( 'shahr-log-admin-style', SHAHR_LOG_URL . '/admin/assets/css/shahr-log-admin-style.css', array(), SHAHR_LOG_VERSION_FR, 'all' );
		wp_enqueue_script( 'shahr-log-admin-js', SHAHR_LOG_URL . '/admin/assets/js/shahr-log-admin-js.js', array( 'jquery' ), SHAHR_LOG_VERSION_FR, false );
		wp_localize_script('shahr-log-admin-js','shahr_log_admin_localize',array(
			'adminurl'  => admin_url().'admin-ajax.php',
		));
	}
	public function add_menu_pages(){

		$args = array(
			'menu_title' 	=>__('Shahr Login','shahr-login') ,
			'icon' 			=> 'dashicons-lock',
			'has_submenu' 	=> true
		);

		shahr_log_helper()->admin->register_menu_page( $args );
		add_submenu_page(
			'shahr-login-settings',
			'Fields',
			__('Fields','shahr-login'),
    		'manage_options',
    		'shahr-log-fields',
    		array( $this, 'admin_fields_page' )
    	);
	}


	//Fields page callback
	public function admin_fields_page(){
		shahr_log()->aff->admin->display_page();
	}

	//Inline CSS
	public function inline_css(){
		if( isset( $_GET['shahr_log_nav'] ) ){
			?>
			<style type="text/css">
				li#shahr_log_actions_link .accordion-section-title {
				    background-color: #007cba;
				    color: #fff;
				}
			</style>
			<?php
		}
	}
}
function shahr_log_admin_settings(){
	return Shahr_Log_Admin_Settings::get_instance();
}
shahr_log_admin_settings();
?>