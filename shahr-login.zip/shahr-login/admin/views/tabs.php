<?php

$tabs = array(
	'general' => array(
		'title'			=> 'General',
		'id' 			=> 'general',
		'option_key' 	=> 'shahr-log-gl-options'
	),

	'style' => array(
		'title'			=> 'Style',
		'id' 			=> 'style',
		'option_key' 	=> 'shahr-log-sy-options'
	),

	'advanced' => array(
		'title'			=> 'Advanced',
		'id' 			=> 'advanced',
		'option_key' 	=> 'shahr-log-av-options'
	),
	'OTP' => array(
		'title'			=> 'OTP',
		'id' 			=> 'OTP',
		'option_key' 	=> 'shahr-log-otp-options'
	),
);

return apply_filters( 'shahr_log_admin_settings_tabs', $tabs );