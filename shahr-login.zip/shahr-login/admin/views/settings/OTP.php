<?php
$settings = array(
    array(
		'callback' 		=> 'checkbox',
		'title' 		=> 'OTP Enable',
		'id' 			=> 'OTP_enable',
		'section_id' 	=> 'se_OTP',
		'default' 		=> 'no',
	),
    array(
		'callback' 		=> 'select',
		'title' 		=> 'Select Gateways',
		'id' 			=> 'otp_gateways',
		'section_id' 	=> 'se_OTP',
		'default' 		=> 'raygansms',
		'desc' 			=> 'Select a gateway for send OTP code ',
		'args'			=> array(
			'options' => array('raygansms'=>'raygansms') 
		),
	),
    array(
		'callback' 		=> 'text',
		'title' 		=> 'OTP User Name',
		'id' 			=> 'OTP_user_name',
		'section_id' 	=> 'se_OTP',
	),
	array(
		'callback' 		=> 'text',
		'title' 		=> 'OTP Password',
		'id' 			=> 'OTP_password',
		'section_id' 	=> 'se_OTP',
	),
	array(
		'callback' 		=> 'text',
		'title' 		=> 'OTP Number',
		'id' 			=> 'OTP_number',
		'section_id' 	=> 'se_OTP',
		
	),
	array(
		'callback' 		=> 'select',
		'title' 		=> 'Number of authentication ',
		'id' 			=> 'OTP_number_of_authentication',
		'section_id' 	=> 'se_OTP',
		'args'			=> array(
			'options'=>array(
				'4' => '4',
				'5' => '5',
				'6' => '6',
				'7' => '7',
				'8' => '8',
				'9' => '9',
				'10' => '10',
			)
		),

	),
	array(
		'callback' 		=> 'checkbox',
		'title' 		=> 'Use Digits Phone Number',
		'id' 			=> 'Digits_enable',
		'section_id' 	=> 'se_OTP',
		'default' 		=> 'no',
	),
	array(
		'callback' 		=> 'textarea',
		'title' 		=> 'OTP Message',
		'id' 			=> 'OTP_Message',
		'section_id' 	=> 'se_OTP',
		'desc' 			=> 'place OTP and  in {authentication}'
	),
	array(
		'callback' 		=> 'select',
		'title' 		=> 'Custom Meta Key',
		'id' 			=> 'CMK_phone_number',
		'section_id' 	=> 'se_OTP',
		'default' 		=> '',
		'args'			=> array(
			'options' => shahr_log_get_user_meta()
		),
		
		
	),
);
function shahr_log_get_user_meta(){
	global $wpdb;
	$meta_keys=array(" ");
	$table_name=$wpdb->prefix."usermeta";
	$results=$wpdb->get_results($wpdb->prepare("SELECT DISTINCT `meta_key` FROM $table_name  WHERE `meta_key` LIKE '%phone%' OR '%number%' OR '%tell%' OR 'digit' "));
	foreach($results as $result ){
		$meta_keys[$result->meta_key]=$result->meta_key;
	}
	return $meta_keys;
}
return apply_filters( 'shahr_log_admin_settings', $settings, 'OTP' );